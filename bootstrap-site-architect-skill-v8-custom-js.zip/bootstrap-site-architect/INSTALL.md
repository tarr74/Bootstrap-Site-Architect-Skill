# Install Bootstrap Site Architect Skill v8

## Windows user scope

Extract the internal folder:

```text
bootstrap-site-architect
```

to:

```text
C:\Users\TUO_NOME_UTENTE\.agents\skills\bootstrap-site-architect\
```

The main file must be here:

```text
C:\Users\TUO_NOME_UTENTE\.agents\skills\bootstrap-site-architect\SKILL.md
```

Avoid a double folder such as:

```text
bootstrap-site-architect\bootstrap-site-architect\SKILL.md
```

## macOS/Linux user scope

```bash
mkdir -p ~/.agents/skills
cp -r bootstrap-site-architect ~/.agents/skills/
```

## Repository scope

Inside a project repository:

```bash
mkdir -p .agents/skills
cp -r bootstrap-site-architect .agents/skills/
```

## Optional separate community frontend-design install

This Bootstrap skill already includes an integrated frontend-design layer. A separate install is not required.

If you still want to install the community skill separately, check the current repository structure. At the time this package was prepared, the path was:

```bash
mkdir -p ~/.agents/skills
git clone https://github.com/vipulgupta2048/codex-skills.git
cp -r codex-skills/skills/frontend-design ~/.agents/skills/
```

Do not copy from `codex-skills/frontend-design` unless that folder exists after cloning.

## Usage prompt

```text
Usa la skill bootstrap-site-architect per modificare questa pagina Bootstrap/PHP. Lavora come web designer, art director tecnico, front-end refactorer, browser tester e SEO/performance auditor. Usa Bootstrap per struttura e componenti; metti tutto lo stile custom in un CSS esterno caricato dopo Bootstrap; non modificare i file originali Bootstrap; preserva PHP, form handler, SEO e testi importanti.
```


## JavaScript policy

Do not modify Bootstrap JavaScript files. Put site-specific behavior in external custom scripts such as `site.js`, `custom.js`, or page-specific files loaded separately.
