#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const file = process.argv[2];
if (!file) {
  console.error('Usage: node scripts/dom-map.mjs <file.html|php>');
  process.exit(1);
}

const html = readFileSync(file, 'utf8');
const re = /<(header|nav|main|section|article|aside|footer|form)\b([^>]*)>/gi;
let match;
while ((match = re.exec(html))) {
  const tag = match[1].toLowerCase();
  const attrs = match[2] || '';
  const id = attrs.match(/\bid=["']([^"']+)["']/i)?.[1];
  const cls = attrs.match(/\bclass=["']([^"']+)["']/i)?.[1];
  const block = attrs.match(/\bdata-edit-block=["']([^"']+)["']/i)?.[1];
  const label = block ? `[${block.toUpperCase()}]` : `[${tag.toUpperCase()}]`;
  console.log(`${label} <${tag}>${id ? '#' + id : ''}${cls ? '.' + cls.trim().replace(/\s+/g, '.') : ''}`);
}
