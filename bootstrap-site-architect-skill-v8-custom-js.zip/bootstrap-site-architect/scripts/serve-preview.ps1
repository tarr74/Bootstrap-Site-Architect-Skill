param(
  [string]$Root = ".",
  [int]$Port = 8000
)
Write-Host "Serving $Root at http://127.0.0.1:$Port/"
php -S "127.0.0.1:$Port" -t $Root
