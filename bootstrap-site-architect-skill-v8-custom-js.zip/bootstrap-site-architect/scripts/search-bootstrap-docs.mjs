#!/usr/bin/env node
/* Search the modular Bootstrap docs shipped with this skill. Usage: node scripts/search-bootstrap-docs.mjs "navbar collapse" */
import fs from 'node:fs';
import path from 'node:path';
const q = process.argv.slice(2).join(' ').trim().toLowerCase();
if (!q) { console.error('Usage: node scripts/search-bootstrap-docs.mjs "query"'); process.exit(1); }
const root = path.resolve(process.cwd(), 'references/bootstrap-docs-full');
const terms = q.split(/\s+/).filter(Boolean);
const results = [];
function walk(dir){
  for (const item of fs.readdirSync(dir, {withFileTypes:true})) {
    const p = path.join(dir, item.name);
    if (item.isDirectory()) walk(p);
    else if (item.isFile() && item.name.endsWith('.md')) {
      const text = fs.readFileSync(p, 'utf8').toLowerCase();
      const score = terms.reduce((n,t)=> n + (text.includes(t) ? 1 : 0), 0);
      if (score) results.push({score, p: path.relative(process.cwd(), p)});
    }
  }
}
walk(root);
results.sort((a,b)=> b.score-a.score || a.p.localeCompare(b.p));
for (const r of results.slice(0,20)) console.log(`${r.score}\t${r.p}`);
