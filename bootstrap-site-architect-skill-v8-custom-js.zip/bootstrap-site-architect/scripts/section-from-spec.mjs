#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const file = process.argv[2];
if (!file) {
  console.error('Usage: node scripts/section-from-spec.mjs spec.json');
  process.exit(1);
}

const spec = JSON.parse(readFileSync(file, 'utf8'));
const id = spec.id || 'custom-section';
const container = spec.fullWidth ? 'container-fluid' : 'container';
const cols = spec.columns || [
  { width: 4, title: 'Titolo prima colonna', paragraphs: ['Primo paragrafo.', 'Secondo paragrafo.', 'Terzo paragrafo.'] },
  { width: 8, title: 'Titolo seconda colonna', subtitle: 'Sottotitolo', paragraphs: ['Contenuto seconda colonna.'] }
];

const html = `<section class="${id} py-5" aria-labelledby="${id}-title">
  <div class="${container}">
    <div class="row g-4 align-items-stretch">
${cols.map((col, i) => `      <div class="col-12 col-lg-${col.width || 12}">
        <div class="${id}__panel ${id}__panel--${i + 1} h-100 p-4 p-lg-5">
          <h2${i === 0 ? ` id="${id}-title"` : ''}>${col.title || `Titolo colonna ${i + 1}`}</h2>
${col.subtitle ? `          <h3>${col.subtitle}</h3>\n` : ''}${(col.paragraphs || ['Testo di esempio.']).map(p => `          <p>${p}</p>`).join('\n')}
        </div>
      </div>`).join('\n')}
    </div>
  </div>
</section>`;

console.log(html);
