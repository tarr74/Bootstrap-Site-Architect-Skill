#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
PORT="${2:-8000}"
echo "Serving ${ROOT} at http://127.0.0.1:${PORT}/"
php -S "127.0.0.1:${PORT}" -t "${ROOT}"
