# SEO, performance, accessibility audit rules

## SEO

- One clear `<title>` matching search intent.
- One H1 per production page.
- Logical H2/H3 hierarchy.
- Meta description written for click-through, not stuffing.
- Canonical URL when appropriate.
- Open Graph/Twitter metadata for shareable pages.
- Descriptive internal anchors.
- Breadcrumb UI and JSON-LD only when a visible hierarchy supports them.
- Schema.org only for facts actually present.
- Local/service pages should show visible contact/location/trust elements when available.
- FAQ only when the page truly answers those questions.

Never invent facts.

## Accessibility

- Semantic landmarks.
- Labels for all form controls.
- `aria-describedby` for help/error text.
- Real buttons/links.
- Keyboard-reachable interactive elements.
- Visible focus states.
- Sufficient contrast for custom colors.
- Meaningful image `alt`; empty alt for decorative images.
- `prefers-reduced-motion` respected for animations.
- Avoid hover-only or tooltip-only essential content.

## Performance

- No dependency by habit.
- Avoid Bootstrap JS bundle if no JS components are used.
- Defer non-critical JS.
- Minimize custom CSS and avoid duplicate rules.
- Use `loading="lazy"` for non-critical images.
- Add `width` and `height` to images when dimensions are known.
- Use responsive images for large media.
- Avoid duplicated DOM for mobile/desktop.
- Prevent CLS with dimensions/placeholders.
- Compress hero/LCP image; preload only when justified.
- Avoid autoplay hero carousel/video as default.
- Cache/minify static assets in production.

## Audit output

Report only what was checked. Separate:

- verified issues,
- likely issues from code inspection,
- recommendations requiring external tools.
