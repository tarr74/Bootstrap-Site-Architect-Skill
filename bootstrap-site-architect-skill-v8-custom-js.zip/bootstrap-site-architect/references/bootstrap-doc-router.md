# Bootstrap documentation router

Use this router to avoid wasting context. Start with the user task, then open only the listed files. Do not read the whole `bootstrap-docs-full/` tree unless the user explicitly asks for a complete audit or you cannot resolve uncertainty from the targeted files.

## Core skill references

- Natural language section/layout request: `references/natural-language-section-builder.md`.
- Existing HTML/PHP refactor: `references/php-html-safe-refactor.md`.
- Visual/WYSIWYG-like editing loop: `references/visual-design-loop.md`.
- Text insertion or rewriting: `references/text-content-editing.md`.
- Custom visual style, colors, typography, custom stylesheet placement, or Bootstrap immutability: `references/bootstrap-custom-css-policy.md`.
- Strong art direction / integrated frontend-design / anti-generic Bootstrap page: `references/frontend-design-interop.md`, then `references/frontend-design-bootstrap-layer.md` for substantial design work.
- SEO/performance/a11y: `references/seo-performance-a11y.md`.
- Common component patterns: `references/component-patterns.md`.
- Final checks: `references/checklists.md`.

## Full Bootstrap 5.3 docs by menu topic

The complete topic-level docs extracted from the user-provided offline archive are in `references/bootstrap-docs-full/`. `About` is intentionally omitted.

Open `references/bootstrap-docs-full/INDEX.md` only when you need to see the full map. Usually open directly one or two topic files from this list.

### Getting started

- Introduction: `references/bootstrap-docs-full/getting-started/introduction.md`
- Download: `references/bootstrap-docs-full/getting-started/download.md`
- Contents: `references/bootstrap-docs-full/getting-started/contents.md`
- Browsers & devices: `references/bootstrap-docs-full/getting-started/browsers-devices.md`
- JavaScript: `references/bootstrap-docs-full/getting-started/javascript.md`
- Custom/non-Bootstrap JavaScript policy: `references/bootstrap-custom-js-policy.md`
- Webpack: `references/bootstrap-docs-full/getting-started/webpack.md`
- Parcel: `references/bootstrap-docs-full/getting-started/parcel.md`
- Vite: `references/bootstrap-docs-full/getting-started/vite.md`
- Accessibility: `references/bootstrap-docs-full/getting-started/accessibility.md`
- RFS: `references/bootstrap-docs-full/getting-started/rfs.md`
- RTL: `references/bootstrap-docs-full/getting-started/rtl.md`
- Contribute: `references/bootstrap-docs-full/getting-started/contribute.md`

### Customize

- Overview: `references/bootstrap-docs-full/customize/overview.md`
- Sass: `references/bootstrap-docs-full/customize/sass.md`
- Options: `references/bootstrap-docs-full/customize/options.md`
- Color: `references/bootstrap-docs-full/customize/color.md`
- Color modes: `references/bootstrap-docs-full/customize/color-modes.md`
- Components: `references/bootstrap-docs-full/customize/components.md`
- CSS variables: `references/bootstrap-docs-full/customize/css-variables.md`
- Optimize: `references/bootstrap-docs-full/customize/optimize.md`

### Layout

- Breakpoints: `references/bootstrap-docs-full/layout/breakpoints.md`
- Containers: `references/bootstrap-docs-full/layout/containers.md`
- Grid: `references/bootstrap-docs-full/layout/grid.md`
- Columns: `references/bootstrap-docs-full/layout/columns.md`
- Gutters: `references/bootstrap-docs-full/layout/gutters.md`
- Utilities: `references/bootstrap-docs-full/layout/utilities.md`
- Z-index: `references/bootstrap-docs-full/layout/z-index.md`
- CSS Grid: `references/bootstrap-docs-full/layout/css-grid.md`

### Content

- Reboot: `references/bootstrap-docs-full/content/reboot.md`
- Typography: `references/bootstrap-docs-full/content/typography.md`
- Images: `references/bootstrap-docs-full/content/images.md`
- Tables: `references/bootstrap-docs-full/content/tables.md`
- Figures: `references/bootstrap-docs-full/content/figures.md`

### Forms

- Overview: `references/bootstrap-docs-full/forms/overview.md`
- Form control: `references/bootstrap-docs-full/forms/form-control.md`
- Select: `references/bootstrap-docs-full/forms/select.md`
- Checks & radios: `references/bootstrap-docs-full/forms/checks-radios.md`
- Range: `references/bootstrap-docs-full/forms/range.md`
- Input group: `references/bootstrap-docs-full/forms/input-group.md`
- Floating labels: `references/bootstrap-docs-full/forms/floating-labels.md`
- Layout: `references/bootstrap-docs-full/forms/layout.md`
- Validation: `references/bootstrap-docs-full/forms/validation.md`

### Components

- Accordion: `references/bootstrap-docs-full/components/accordion.md`
- Alerts: `references/bootstrap-docs-full/components/alerts.md`
- Badge: `references/bootstrap-docs-full/components/badge.md`
- Breadcrumb: `references/bootstrap-docs-full/components/breadcrumb.md`
- Buttons: `references/bootstrap-docs-full/components/buttons.md`
- Button group: `references/bootstrap-docs-full/components/button-group.md`
- Card: `references/bootstrap-docs-full/components/card.md`
- Carousel: `references/bootstrap-docs-full/components/carousel.md`
- Close button: `references/bootstrap-docs-full/components/close-button.md`
- Collapse: `references/bootstrap-docs-full/components/collapse.md`
- Dropdowns: `references/bootstrap-docs-full/components/dropdowns.md`
- List group: `references/bootstrap-docs-full/components/list-group.md`
- Modal: `references/bootstrap-docs-full/components/modal.md`
- Navbar: `references/bootstrap-docs-full/components/navbar.md`
- Navs & tabs: `references/bootstrap-docs-full/components/navs-tabs.md`
- Offcanvas: `references/bootstrap-docs-full/components/offcanvas.md`
- Pagination: `references/bootstrap-docs-full/components/pagination.md`
- Placeholders: `references/bootstrap-docs-full/components/placeholders.md`
- Popovers: `references/bootstrap-docs-full/components/popovers.md`
- Progress: `references/bootstrap-docs-full/components/progress.md`
- Scrollspy: `references/bootstrap-docs-full/components/scrollspy.md`
- Spinners: `references/bootstrap-docs-full/components/spinners.md`
- Toasts: `references/bootstrap-docs-full/components/toasts.md`
- Tooltips: `references/bootstrap-docs-full/components/tooltips.md`

### Helpers

- Clearfix: `references/bootstrap-docs-full/helpers/clearfix.md`
- Color & background: `references/bootstrap-docs-full/helpers/color-background.md`
- Colored links: `references/bootstrap-docs-full/helpers/colored-links.md`
- Focus ring: `references/bootstrap-docs-full/helpers/focus-ring.md`
- Icon link: `references/bootstrap-docs-full/helpers/icon-link.md`
- Position: `references/bootstrap-docs-full/helpers/position.md`
- Ratio: `references/bootstrap-docs-full/helpers/ratio.md`
- Stacks: `references/bootstrap-docs-full/helpers/stacks.md`
- Stretched link: `references/bootstrap-docs-full/helpers/stretched-link.md`
- Text truncation: `references/bootstrap-docs-full/helpers/text-truncation.md`
- Vertical rule: `references/bootstrap-docs-full/helpers/vertical-rule.md`
- Visually hidden: `references/bootstrap-docs-full/helpers/visually-hidden.md`

### Utilities

- API: `references/bootstrap-docs-full/utilities/api.md`
- Background: `references/bootstrap-docs-full/utilities/background.md`
- Borders: `references/bootstrap-docs-full/utilities/borders.md`
- Colors: `references/bootstrap-docs-full/utilities/colors.md`
- Display: `references/bootstrap-docs-full/utilities/display.md`
- Flex: `references/bootstrap-docs-full/utilities/flex.md`
- Float: `references/bootstrap-docs-full/utilities/float.md`
- Interactions: `references/bootstrap-docs-full/utilities/interactions.md`
- Link: `references/bootstrap-docs-full/utilities/link.md`
- Object fit: `references/bootstrap-docs-full/utilities/object-fit.md`
- Opacity: `references/bootstrap-docs-full/utilities/opacity.md`
- Overflow: `references/bootstrap-docs-full/utilities/overflow.md`
- Position: `references/bootstrap-docs-full/utilities/position.md`
- Shadows: `references/bootstrap-docs-full/utilities/shadows.md`
- Sizing: `references/bootstrap-docs-full/utilities/sizing.md`
- Spacing: `references/bootstrap-docs-full/utilities/spacing.md`
- Text: `references/bootstrap-docs-full/utilities/text.md`
- Vertical align: `references/bootstrap-docs-full/utilities/vertical-align.md`
- Visibility: `references/bootstrap-docs-full/utilities/visibility.md`
- Z-index: `references/bootstrap-docs-full/utilities/z-index.md`

### Extend

- Approach: `references/bootstrap-docs-full/extend/approach.md`
- Icons: `references/bootstrap-docs-full/extend/icons.md`


## Task-to-doc routing examples

- User asks for a two-column layout, container, gutters, or column fractions -> `layout/grid.md`, `layout/columns.md`, `layout/gutters.md`, optionally `layout/containers.md`.
- User asks for colors, dark mode, CSS variables, or Sass theming -> `customize/color.md`, `customize/color-modes.md`, `customize/css-variables.md`, optionally `customize/sass.md`.
- User asks for a form -> `forms/overview.md` plus the precise controls: `forms/form-control.md`, `forms/select.md`, `forms/checks-radios.md`, `forms/input-group.md`, `forms/validation.md`.
- User asks for navbar/offcanvas menu -> `components/navbar.md`, `components/offcanvas.md`, `components/collapse.md`.
- User asks for cards/course cards/pricing grids -> `components/card.md`, `layout/grid.md`, `utilities/spacing.md`, `utilities/flex.md`.
- User asks for modal/dropdown/tooltip/popover/collapse/accordion -> the corresponding component file and `getting-started/javascript.md`.
- User asks for responsive display, flex alignment, spacing, colors, sizing, overflow, z-index -> the matching `utilities/*.md` file.
- User asks for accessible hiding/focus/ratios/stretched links -> `helpers/visually-hidden.md`, `helpers/focus-ring.md`, `helpers/ratio.md`, `helpers/stretched-link.md`.
- User asks about build tools/CDN/Vite/Webpack/Parcel -> the matching `getting-started/*.md` file.
- User asks about optimization -> `customize/optimize.md`, `seo-performance-a11y.md`, and the specific component/layout files involved.

## Escalation rule

1. First use the task-specific skill reference.
2. Then open at most 1-3 Bootstrap topic docs that match the actual uncertainty.
3. If still uncertain, open `INDEX.md` and choose more files.
4. Never paste long documentation excerpts back to the user; apply the docs to code.

## Integrated frontend-design / art direction

Load `references/frontend-design-interop.md` when the prompt mentions `frontend-design`, `vipulgupta2048/codex-skills`, `npx skills add`, stronger art direction, distinctive UI, anti-generic design, typography/palette strategy, or when a page redesign needs a less templated Bootstrap look.

For substantial page, landing, homepage, template, or visual redesign work, also load `references/frontend-design-bootstrap-layer.md`.

For any non-standard visual styling, load `references/bootstrap-custom-css-policy.md`. Bootstrap original files must never be edited; custom styling belongs in external project CSS loaded after Bootstrap.

Use these with the relevant Bootstrap docs; the art-direction layer does not replace Bootstrap documentation.


## Custom JavaScript routing

When the user asks for behavior that Bootstrap does not already provide, first decide whether a Bootstrap component or data attribute solves it. If not, read `references/bootstrap-custom-js-policy.md`. Never edit Bootstrap/vendor JS files; create or update an external custom script such as `site.js`, `custom.js`, or a page-specific script.
