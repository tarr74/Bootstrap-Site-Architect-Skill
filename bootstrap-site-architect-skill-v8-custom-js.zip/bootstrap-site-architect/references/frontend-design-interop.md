# Frontend-design interoperability and Bootstrap integration

Use this reference when the user mentions:

- `frontend-design`;
- `vipulgupta2048/codex-skills`;
- `npx skills add`;
- Claude Code or other frontend design skills;
- anti-generic UI, distinctive visual direction, or making Bootstrap pages less recognizable as AI/Codex output.

## Source command requested by the user

The user may provide this install pattern:

```bash
mkdir -p ~/.agents/skills

git clone https://github.com/vipulgupta2048/codex-skills.git

cp -r codex-skills/frontend-design ~/.agents/skills/
```

The design intent is right, but the repository structure currently exposes the skill under:

```text
skills/frontend-design
```

So the safer manual copy command is:

```bash
mkdir -p ~/.agents/skills
git clone https://github.com/vipulgupta2048/codex-skills.git
cp -r codex-skills/skills/frontend-design ~/.agents/skills/
```

Do not execute installation commands unless the user explicitly asks and the environment allows it.

## How this Bootstrap skill integrates it

This skill is not a loose bundle of two separate skills. Treat it as a single Bootstrap-first designer skill:

1. Use Bootstrap 5.3 for structure, responsive grid, forms, helpers, utilities, and components.
2. Use the frontend-design layer for art direction: tone, typography, palette, texture, layout signature, motion restraint, and anti-generic polish.
3. Never edit Bootstrap original files.
4. Put every non-standard visual decision in a separate custom stylesheet loaded after Bootstrap.
5. Preserve PHP/server logic, SEO, accessibility, performance, and responsive behavior.

For the detailed integrated design layer, load:

```text
references/frontend-design-bootstrap-layer.md
```

For strict CSS placement rules, load:

```text
references/bootstrap-custom-css-policy.md
```

For source attribution and optional separate install notes, load:

```text
references/third-party-frontend-design-source.md
```

## Quick activation rule

Load the integrated design layer when the task is a substantial new page, landing, template, homepage, course page, portfolio, archive, or visual redesign. Do not load it for small text edits or trivial Bootstrap class fixes.
