# Natural-language Bootstrap section builder

Purpose: let a user describe a section in ordinary language and receive production-ready Bootstrap 5.3 HTML plus external CSS.

## Workflow

1. Parse the request into a compact spec:
   - insertion target or standalone snippet,
   - section width: site-width, full-width, contained, full-bleed background + contained content,
   - rows/columns and fractions,
   - breakpoints,
   - content: exact text, dummy text, headings, links, images,
   - colors, spacing, borders, radius, alignment,
   - Bootstrap components/utilities,
   - custom CSS needed.
2. Validate blockers:
   - invalid CSS colors,
   - columns that exceed 12 without an intentional wrap,
   - conflicting width instructions,
   - multiple production H1s,
   - inaccessible contrast or missing link purpose,
   - ambiguous insertion location in an existing page.
3. Ask only the minimal clarifying question if a blocker exists.
4. Generate or patch HTML and CSS.
5. Explain file placement and how to test.

## Width vocabulary

- “larga come tutto il sito”, “come il resto del sito”, “allineata al sito” -> `.container`.
- “a tutta larghezza”, “full width”, “edge to edge”, “da bordo a bordo” -> `.container-fluid` or a full-bleed wrapper.
- “sfondo full width ma contenuto allineato al sito” -> outer full-width section with inner `.container`.

## Grid vocabulary

Default breakpoint: `lg` unless the user specifies `md`, `xl`, “da tablet”, “da desktop”, etc.

- un dodicesimo -> `col-12 col-lg-1`
- un sesto / 2 su 12 -> `col-12 col-lg-2`
- un quarto / 3 su 12 -> `col-12 col-lg-3`
- un terzo / 4 su 12 -> `col-12 col-lg-4`
- cinque dodicesimi / 5 su 12 -> `col-12 col-lg-5`
- metà / 6 su 12 -> `col-12 col-lg-6`
- sette dodicesimi / 7 su 12 -> `col-12 col-lg-7`
- due terzi / 8 su 12 -> `col-12 col-lg-8`
- tre quarti / 9 su 12 -> `col-12 col-lg-9`
- dieci dodicesimi / 10 su 12 -> `col-12 col-lg-10`
- undici dodicesimi / 11 su 12 -> `col-12 col-lg-11`
- intera / 12 su 12 -> `col-12`

For repeated equal cards use `.row-cols-1 row-cols-md-2 row-cols-lg-3` instead of manual columns.

## Color validation

Valid hex values have 3, 4, 6, or 8 hex digits after `#` and only `0-9a-fA-F`.

- valid: `#fff`, `#ffff`, `#ffffff`, `#ffffffff`
- invalid: `#ff900`, `#gg00ff`, `#12345`

If invalid, ask confirmation. Do not silently repair unless the user previously stated the correction.

## CSS strategy

Use Bootstrap utilities for common spacing/display/flex/text. Use custom CSS for user-specified exact colors and repeated visual treatments.

Prefer a project CSS file:

- existing custom CSS if present,
- otherwise `assets/css/site.css`, `css/site.css`, or similar existing convention.

Class naming:

- Use project prefix when present: `pg-`, `abarc-`, `site-`, etc.
- Otherwise use clear scoped names: `.bsx-split-section`, `.bsx-split-section__primary`.

## Example output pattern

```html
<section class="bsx-split-section py-5" aria-labelledby="bsx-split-title">
  <div class="container">
    <div class="row g-4 align-items-stretch">
      <div class="col-12 col-lg-4">
        <div class="bsx-split-section__panel bsx-split-section__panel--primary h-100 p-4 p-lg-5">
          <h2 id="bsx-split-title">Titolo di esempio</h2>
          <p>Primo paragrafo dimostrativo.</p>
          <p>Secondo paragrafo dimostrativo.</p>
          <p>Terzo paragrafo dimostrativo con <a href="#">un link di esempio</a>.</p>
        </div>
      </div>
      <div class="col-12 col-lg-8">
        <div class="bsx-split-section__panel bsx-split-section__panel--secondary h-100 p-4 p-lg-5">
          <h2>Titolo seconda colonna</h2>
          <h3>Sottotitolo seconda colonna</h3>
          <p>Contenuto dimostrativo della seconda colonna.</p>
        </div>
      </div>
    </div>
  </div>
</section>
```

```css
.bsx-split-section__panel--primary {
  background: #cfcfcf;
  color: #ff9900;
}

.bsx-split-section__panel--primary a {
  color: #ff00ff;
}

.bsx-split-section__panel--primary a:hover,
.bsx-split-section__panel--primary a:focus-visible {
  color: #cc00cc;
}

.bsx-split-section__panel--secondary {
  background: #000;
  color: #fff;
}

.bsx-split-section__panel--secondary h2,
.bsx-split-section__panel--secondary h3 {
  color: #667723;
}
```

Use H2/H3 in production unless this is a standalone dummy file where multiple H1s are acceptable.
