# Bootstrap 5.3 field manual for Codex

Condensed rules distilled from the supplied Bootstrap 5.3 offline documentation. Use this instead of rereading all docs.

## Page foundation

```html
<!doctype html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>...</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  <link href="assets/css/site.css" rel="stylesheet">
</head>
<body>
  ...
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous" defer></script>
</body>
</html>
```

Load Bootstrap CSS before custom CSS. Load Bootstrap bundle only when JS components are needed. In package-managed projects, prefer existing build conventions.

## Grid and layout

- Mobile-first. Put the simplest/mobile class first.
- Standard pattern: `.container` -> `.row` -> direct `.col-*` children.
- Use `.container` for site-width content, `.container-fluid` for full viewport width, responsive containers when the site already uses them.
- Use gutters with `g-*`, `gx-*`, `gy-*`.
- Use `.row-cols-*` for repeated grids.
- Use `.col-auto` for content-sized columns.
- Nest rows only inside columns.
- Fractions: 1/2=`6`, 1/3=`4`, 2/3=`8`, 1/4=`3`, 3/4=`9`.
- Default unknown breakpoint: stack on mobile with `col-12`, apply requested width at `lg`.

## Content

- Use semantic landmarks: `header`, `nav`, `main`, `section`, `article`, `aside`, `footer`.
- Prefer one H1 per production page. Use H2/H3 for sections.
- Use `.lead`, `.display-*`, spacing utilities, and text utilities for appearance, but keep structure semantic.
- Images: `.img-fluid`, real `alt`, `width`, `height`; use `<picture>`/`srcset` for large responsive images.
- Embeds: `.ratio ratio-16x9` or project-appropriate ratio.
- Tables: wrap wide tables in `.table-responsive`.

## Forms

- Every field needs a label. If visually hidden, use `.visually-hidden`.
- Preserve backend `name` attributes.
- Use correct `type`, `autocomplete`, `required` where appropriate.
- Use `.form-control`, `.form-select`, `.form-check`, `.input-group`, `.form-floating`, `.form-text`, `.invalid-feedback` according to the control.
- Link help/error text with `aria-describedby`.
- Bootstrap validation styles are not a substitute for server-side validation.
- Public PHP forms should keep or add honeypot/CSRF where possible.

## Components

- Bootstrap 5 uses `data-bs-*`, not `data-*` from v4.
- Navbar/collapse/offcanvas/modal/accordion/tabs/dropdowns need unique stable IDs.
- Use real buttons for actions and links for navigation.
- Avoid essential content only in tooltip/popover/toast/modal.
- Avoid autoplay carousel as default hero design; it is often poor for performance and accessibility.

## Utilities and helpers

Prefer utilities for simple styling:

- spacing: `m*`, `p*`, `gap-*`
- display: `d-*`
- flex: `d-flex`, `justify-content-*`, `align-items-*`, `flex-*`
- text: `text-*`, `fw-*`, `lh-*`, `text-wrap`, `text-truncate`
- backgrounds/borders/shadows/sizing/position/overflow/object-fit
- helpers: `.visually-hidden`, `.visually-hidden-focusable`, `.ratio`, `.stretched-link`, `.vstack`, `.hstack`, `.vr`, `.focus-ring`

Do not create custom classes that merely duplicate one utility.

## Custom CSS

Use custom CSS for:

- arbitrary colors from the user,
- brand palette,
- repeated section/component patterns,
- exact hover/focus states,
- complex responsive behavior.

Keep it scoped:

```css
.pg-feature-split { ... }
.pg-feature-split__primary { ... }
.pg-feature-split a { ... }
```

Avoid `!important` unless resolving unavoidable legacy conflicts.

## JavaScript

- Use vanilla JS.
- Prefer Bootstrap data attributes for simple plugin behavior.
- Use programmatic APIs only when lifecycle control is needed.
- Use event delegation for dynamic repeated items.
- Load with `defer` or `type="module"`.
- Respect `prefers-reduced-motion`.
