# Download

Source: Bootstrap offline docs `/docs/5.3/getting-started/download/` extracted from the user-provided documentation archive.

Lead: Download Bootstrap to get the compiled CSS and JavaScript, source code, or include it with your favorite package managers like npm, RubyGems, and more.

### Compiled CSS and JS

Download ready-to-use compiled code for **Bootstrap v5.3.0-alpha3** to easily drop into your project, which includes:

- Compiled and minified CSS bundles (see
                CSS files comparison)
- Compiled and minified JavaScript plugins (see
                JS files comparison)

This doesn’t include documentation, source files, or any optional JavaScript dependencies like Popper.

[Download](https://objects.githubusercontent.com/github-production-release-asset-2e65be/2126244/b3d3b1c4-076d-42e2-966a-81b83a496b6b?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIWNJYAX4CSVEH53A%2F20230515%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20230515T132711Z&X-Amz-Expires=300&X-Amz-Signature=de7dd44d50dba7920c0965fc52a979e79ee73094a0211b93a6f1212de14e0251&X-Amz-SignedHeaders=host&actor_id=0&key_id=0&repo_id=2126244&response-content-disposition=attachment%3B%20filename%3Dbootstrap-5.3.0-alpha3-dist.zip&response-content-type=application%2Foctet-stream)


### Source files

Compile Bootstrap with your own asset pipeline by downloading our source Sass, JavaScript, and documentation files. This option requires some additional tooling:

- Sass compiler for
                compiling Sass source files into CSS files
- [Autoprefixer](https://github.com/postcss/autoprefixer)
                for CSS vendor prefixing

Should you require our full set of build tools, they are included for developing Bootstrap and its docs, but they’re likely unsuitable for your own purposes.

[Download source](https://codeload.github.com/twbs/bootstrap/zip/refs/tags/v5.3.0-alpha3)


### Examples

If you want to download and examine our examples, you can grab the already built examples:

[Download Examples](https://objects.githubusercontent.com/github-production-release-asset-2e65be/2126244/743a06c7-6c1c-4107-a14e-3834b6d8902f?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIWNJYAX4CSVEH53A%2F20230515%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20230515T132622Z&X-Amz-Expires=300&X-Amz-Signature=2fdb6a52cacfc1eea9590fc8a5cbe24f1133a3e1422b1666765356200e37e150&X-Amz-SignedHeaders=host&actor_id=0&key_id=0&repo_id=2126244&response-content-disposition=attachment%3B%20filename%3Dbootstrap-5.3.0-alpha3-examples.zip&response-content-type=application%2Foctet-stream)


### CDN via jsDelivr

Skip the download with [jsDelivr](https://www.jsdelivr.com/) to deliver cached version of Bootstrap’s compiled CSS and JS to your project.

```html
<
link
 
href
=
"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css"
 
rel
=
"stylesheet"
 
integrity
=
"sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ"
 
crossorigin
=
"anonymous"
>

<
script
 
src
=
"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
 
integrity
=
"sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
 
crossorigin
=
"anonymous"
></
script
>
```

If you’re using our compiled JavaScript and prefer to include Popper separately, add Popper before our JS, via a CDN preferably.

```html
<
script
 
src
=
"https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"
 
integrity
=
"sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE"
 
crossorigin
=
"anonymous"
></
script
>

<
script
 
src
=
"https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"
 
integrity
=
"sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ"
 
crossorigin
=
"anonymous"
></
script
>
```


### Package managers

Pull in Bootstrap’s **source files** into nearly any project with some of the most popular package managers. No matter the package manager, Bootstrap will **require a Sass compiler and [Autoprefixer](https://github.com/postcss/autoprefixer)** for a setup that matches our official compiled versions.


#### npm

Install Bootstrap in your Node.js powered apps with [the npm package](https://www.npmjs.com/package/bootstrap):

```sh
npm install bootstrap@5.3.0-alpha3
```

`const bootstrap = require('bootstrap')` or `import bootstrap from 'bootstrap'` will load all of Bootstrap’s plugins onto a `bootstrap` object. The `bootstrap` module itself exports all of our plugins. You can manually load Bootstrap’s plugins individually by loading the `/js/dist/*.js` files under the package’s top-level directory.

Bootstrap’s `package.json` contains some additional metadata under the following keys:

- `sass` - path to Bootstrap’s main
                [Sass](https://sass-lang.com/) source file
- `style` - path to Bootstrap’s non-minified CSS
                that’s been compiled using the default settings (no
                customization)

> Note: Get started with Bootstrap via npm with our starter project!

Head to the

Sass & JS example

template repository to see how to build and customize Bootstrap in your own npm project. Includes Sass compiler, Autoprefixer, Stylelint, PurgeCSS, and Bootstrap Icons.


#### yarn

Install Bootstrap in your Node.js powered apps with [the yarn package](https://yarnpkg.com/en/package/bootstrap):

```sh
yarn add bootstrap@5.3.0-alpha3
```


#### RubyGems

Install Bootstrap in your Ruby apps using [Bundler](https://bundler.io/) (**recommended**) and [RubyGems](https://rubygems.org/) by adding the following line to your [`Gemfile`](https://bundler.io/gemfile.html):

```ruby
gem
 
'bootstrap'
,
 
'~> 5.3.0.alpha3'
```

Alternatively, if you’re not using Bundler, you can install the gem by running this command:

```sh
gem install bootstrap -v 5.3.0.alpha3
```

[See the gem’s README](https://github.com/twbs/bootstrap-rubygem/blob/main/README.md) for further details.


#### Composer

You can also install and manage Bootstrap’s Sass and JavaScript using [Composer](https://getcomposer.org/):

```sh
composer require twbs/bootstrap:5.3.0-alpha3
```


#### NuGet

If you develop in .NET Framework, you can also install and manage Bootstrap’s [CSS](https://www.nuget.org/packages/bootstrap/) or [Sass](https://www.nuget.org/packages/bootstrap.sass/) and JavaScript using [NuGet](https://www.nuget.org/). Newer projects should use [libman](https://docs.microsoft.com/en-us/aspnet/core/client-side/libman/) or another method as NuGet is designed for compiled code, not frontend assets.

```powershell
Install-Package
 
bootstrap
```

```powershell
Install-Package
 
bootstrap
.
sass
```
