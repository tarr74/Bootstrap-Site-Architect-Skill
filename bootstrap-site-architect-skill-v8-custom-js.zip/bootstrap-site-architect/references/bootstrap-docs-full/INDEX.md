# Bootstrap 5.3 full documentation index

Generated from the user-provided offline Bootstrap documentation. The About section is intentionally omitted.

Codex rule: do not read this whole folder by default. Use this index and the router to load only the smallest relevant topic files.

## Getting started

- [Introduction](getting-started/introduction.md) — `references/bootstrap-docs-full/getting-started/introduction.md`
- [Download](getting-started/download.md) — `references/bootstrap-docs-full/getting-started/download.md`
- [Contents](getting-started/contents.md) — `references/bootstrap-docs-full/getting-started/contents.md`
- [Browsers & devices](getting-started/browsers-devices.md) — `references/bootstrap-docs-full/getting-started/browsers-devices.md`
- [JavaScript](getting-started/javascript.md) — `references/bootstrap-docs-full/getting-started/javascript.md`
- [Webpack](getting-started/webpack.md) — `references/bootstrap-docs-full/getting-started/webpack.md`
- [Parcel](getting-started/parcel.md) — `references/bootstrap-docs-full/getting-started/parcel.md`
- [Vite](getting-started/vite.md) — `references/bootstrap-docs-full/getting-started/vite.md`
- [Accessibility](getting-started/accessibility.md) — `references/bootstrap-docs-full/getting-started/accessibility.md`
- [RFS](getting-started/rfs.md) — `references/bootstrap-docs-full/getting-started/rfs.md`
- [RTL](getting-started/rtl.md) — `references/bootstrap-docs-full/getting-started/rtl.md`
- [Contribute](getting-started/contribute.md) — `references/bootstrap-docs-full/getting-started/contribute.md`

## Customize

- [Overview](customize/overview.md) — `references/bootstrap-docs-full/customize/overview.md`
- [Sass](customize/sass.md) — `references/bootstrap-docs-full/customize/sass.md`
- [Options](customize/options.md) — `references/bootstrap-docs-full/customize/options.md`
- [Color](customize/color.md) — `references/bootstrap-docs-full/customize/color.md`
- [Color modes](customize/color-modes.md) — `references/bootstrap-docs-full/customize/color-modes.md`
- [Components](customize/components.md) — `references/bootstrap-docs-full/customize/components.md`
- [CSS variables](customize/css-variables.md) — `references/bootstrap-docs-full/customize/css-variables.md`
- [Optimize](customize/optimize.md) — `references/bootstrap-docs-full/customize/optimize.md`

## Layout

- [Breakpoints](layout/breakpoints.md) — `references/bootstrap-docs-full/layout/breakpoints.md`
- [Containers](layout/containers.md) — `references/bootstrap-docs-full/layout/containers.md`
- [Grid](layout/grid.md) — `references/bootstrap-docs-full/layout/grid.md`
- [Columns](layout/columns.md) — `references/bootstrap-docs-full/layout/columns.md`
- [Gutters](layout/gutters.md) — `references/bootstrap-docs-full/layout/gutters.md`
- [Utilities](layout/utilities.md) — `references/bootstrap-docs-full/layout/utilities.md`
- [Z-index](layout/z-index.md) — `references/bootstrap-docs-full/layout/z-index.md`
- [CSS Grid](layout/css-grid.md) — `references/bootstrap-docs-full/layout/css-grid.md`

## Content

- [Reboot](content/reboot.md) — `references/bootstrap-docs-full/content/reboot.md`
- [Typography](content/typography.md) — `references/bootstrap-docs-full/content/typography.md`
- [Images](content/images.md) — `references/bootstrap-docs-full/content/images.md`
- [Tables](content/tables.md) — `references/bootstrap-docs-full/content/tables.md`
- [Figures](content/figures.md) — `references/bootstrap-docs-full/content/figures.md`

## Forms

- [Overview](forms/overview.md) — `references/bootstrap-docs-full/forms/overview.md`
- [Form control](forms/form-control.md) — `references/bootstrap-docs-full/forms/form-control.md`
- [Select](forms/select.md) — `references/bootstrap-docs-full/forms/select.md`
- [Checks & radios](forms/checks-radios.md) — `references/bootstrap-docs-full/forms/checks-radios.md`
- [Range](forms/range.md) — `references/bootstrap-docs-full/forms/range.md`
- [Input group](forms/input-group.md) — `references/bootstrap-docs-full/forms/input-group.md`
- [Floating labels](forms/floating-labels.md) — `references/bootstrap-docs-full/forms/floating-labels.md`
- [Layout](forms/layout.md) — `references/bootstrap-docs-full/forms/layout.md`
- [Validation](forms/validation.md) — `references/bootstrap-docs-full/forms/validation.md`

## Components

- [Accordion](components/accordion.md) — `references/bootstrap-docs-full/components/accordion.md`
- [Alerts](components/alerts.md) — `references/bootstrap-docs-full/components/alerts.md`
- [Badge](components/badge.md) — `references/bootstrap-docs-full/components/badge.md`
- [Breadcrumb](components/breadcrumb.md) — `references/bootstrap-docs-full/components/breadcrumb.md`
- [Buttons](components/buttons.md) — `references/bootstrap-docs-full/components/buttons.md`
- [Button group](components/button-group.md) — `references/bootstrap-docs-full/components/button-group.md`
- [Card](components/card.md) — `references/bootstrap-docs-full/components/card.md`
- [Carousel](components/carousel.md) — `references/bootstrap-docs-full/components/carousel.md`
- [Close button](components/close-button.md) — `references/bootstrap-docs-full/components/close-button.md`
- [Collapse](components/collapse.md) — `references/bootstrap-docs-full/components/collapse.md`
- [Dropdowns](components/dropdowns.md) — `references/bootstrap-docs-full/components/dropdowns.md`
- [List group](components/list-group.md) — `references/bootstrap-docs-full/components/list-group.md`
- [Modal](components/modal.md) — `references/bootstrap-docs-full/components/modal.md`
- [Navbar](components/navbar.md) — `references/bootstrap-docs-full/components/navbar.md`
- [Navs & tabs](components/navs-tabs.md) — `references/bootstrap-docs-full/components/navs-tabs.md`
- [Offcanvas](components/offcanvas.md) — `references/bootstrap-docs-full/components/offcanvas.md`
- [Pagination](components/pagination.md) — `references/bootstrap-docs-full/components/pagination.md`
- [Placeholders](components/placeholders.md) — `references/bootstrap-docs-full/components/placeholders.md`
- [Popovers](components/popovers.md) — `references/bootstrap-docs-full/components/popovers.md`
- [Progress](components/progress.md) — `references/bootstrap-docs-full/components/progress.md`
- [Scrollspy](components/scrollspy.md) — `references/bootstrap-docs-full/components/scrollspy.md`
- [Spinners](components/spinners.md) — `references/bootstrap-docs-full/components/spinners.md`
- [Toasts](components/toasts.md) — `references/bootstrap-docs-full/components/toasts.md`
- [Tooltips](components/tooltips.md) — `references/bootstrap-docs-full/components/tooltips.md`

## Helpers

- [Clearfix](helpers/clearfix.md) — `references/bootstrap-docs-full/helpers/clearfix.md`
- [Color & background](helpers/color-background.md) — `references/bootstrap-docs-full/helpers/color-background.md`
- [Colored links](helpers/colored-links.md) — `references/bootstrap-docs-full/helpers/colored-links.md`
- [Focus ring](helpers/focus-ring.md) — `references/bootstrap-docs-full/helpers/focus-ring.md`
- [Icon link](helpers/icon-link.md) — `references/bootstrap-docs-full/helpers/icon-link.md`
- [Position](helpers/position.md) — `references/bootstrap-docs-full/helpers/position.md`
- [Ratio](helpers/ratio.md) — `references/bootstrap-docs-full/helpers/ratio.md`
- [Stacks](helpers/stacks.md) — `references/bootstrap-docs-full/helpers/stacks.md`
- [Stretched link](helpers/stretched-link.md) — `references/bootstrap-docs-full/helpers/stretched-link.md`
- [Text truncation](helpers/text-truncation.md) — `references/bootstrap-docs-full/helpers/text-truncation.md`
- [Vertical rule](helpers/vertical-rule.md) — `references/bootstrap-docs-full/helpers/vertical-rule.md`
- [Visually hidden](helpers/visually-hidden.md) — `references/bootstrap-docs-full/helpers/visually-hidden.md`

## Utilities

- [API](utilities/api.md) — `references/bootstrap-docs-full/utilities/api.md`
- [Background](utilities/background.md) — `references/bootstrap-docs-full/utilities/background.md`
- [Borders](utilities/borders.md) — `references/bootstrap-docs-full/utilities/borders.md`
- [Colors](utilities/colors.md) — `references/bootstrap-docs-full/utilities/colors.md`
- [Display](utilities/display.md) — `references/bootstrap-docs-full/utilities/display.md`
- [Flex](utilities/flex.md) — `references/bootstrap-docs-full/utilities/flex.md`
- [Float](utilities/float.md) — `references/bootstrap-docs-full/utilities/float.md`
- [Interactions](utilities/interactions.md) — `references/bootstrap-docs-full/utilities/interactions.md`
- [Link](utilities/link.md) — `references/bootstrap-docs-full/utilities/link.md`
- [Object fit](utilities/object-fit.md) — `references/bootstrap-docs-full/utilities/object-fit.md`
- [Opacity](utilities/opacity.md) — `references/bootstrap-docs-full/utilities/opacity.md`
- [Overflow](utilities/overflow.md) — `references/bootstrap-docs-full/utilities/overflow.md`
- [Position](utilities/position.md) — `references/bootstrap-docs-full/utilities/position.md`
- [Shadows](utilities/shadows.md) — `references/bootstrap-docs-full/utilities/shadows.md`
- [Sizing](utilities/sizing.md) — `references/bootstrap-docs-full/utilities/sizing.md`
- [Spacing](utilities/spacing.md) — `references/bootstrap-docs-full/utilities/spacing.md`
- [Text](utilities/text.md) — `references/bootstrap-docs-full/utilities/text.md`
- [Vertical align](utilities/vertical-align.md) — `references/bootstrap-docs-full/utilities/vertical-align.md`
- [Visibility](utilities/visibility.md) — `references/bootstrap-docs-full/utilities/visibility.md`
- [Z-index](utilities/z-index.md) — `references/bootstrap-docs-full/utilities/z-index.md`

## Extend

- [Approach](extend/approach.md) — `references/bootstrap-docs-full/extend/approach.md`
- [Icons](extend/icons.md) — `references/bootstrap-docs-full/extend/icons.md`
