# Range

Source: Bootstrap offline docs `/docs/5.3/forms/range/` extracted from the user-provided documentation archive.

Lead: Use our custom range inputs for consistent cross-browser styling and built-in customization.

### Overview

Create custom `<input type="range">` controls with `.form-range`. The track (the background) and thumb (the value) are both styled to appear the same across browsers. As only Firefox supports “filling” their track from the left or right of the thumb as a means to visually indicate progress, we do not currently support it.

Example range

```html
<
label
 
for
=
"customRange1"
 
class
=
"form-label"
>
Example range
</
label
>

<
input
 
type
=
"range"
 
class
=
"form-range"
 
id
=
"customRange1"
>
```


### Disabled

Add the `disabled` boolean attribute on an input to give it a grayed out appearance, remove pointer events, and prevent focusing.

Disabled range

```html
<
label
 
for
=
"disabledRange"
 
class
=
"form-label"
>
Disabled range
</
label
>

<
input
 
type
=
"range"
 
class
=
"form-range"
 
id
=
"disabledRange"
 
disabled
>
```


### Min and max

Range inputs have implicit values for `min` and `max`—`0` and `100`, respectively. You may specify new values for those using the `min` and `max` attributes.

Example range

```html
<
label
 
for
=
"customRange2"
 
class
=
"form-label"
>
Example range
</
label
>

<
input
 
type
=
"range"
 
class
=
"form-range"
 
min
=
"0"
 
max
=
"5"
 
id
=
"customRange2"
>
```


### Steps

By default, range inputs “snap” to integer values. To change this, you can specify a `step` value. In the example below, we double the number of steps by using `step="0.5"`.

Example range

```html
<
label
 
for
=
"customRange3"
 
class
=
"form-label"
>
Example range
</
label
>

<
input
 
type
=
"range"
 
class
=
"form-range"
 
min
=
"0"
 
max
=
"5"
 
step
=
"0.5"
 
id
=
"customRange3"
>
```


### CSS


#### Sass variables

```scss
$form-range-track-width
:
          
100
%
;

$form-range-track-height
:
         
.5
rem
;

$form-range-track-cursor
:
         
pointer
;

$form-range-track-bg
:
             
var
(
--
#{
$prefix
}
tertiary-bg
);

$form-range-track-border-radius
:
  
1
rem
;

$form-range-track-box-shadow
:
     
$box-shadow-inset
;

$form-range-thumb-width
:
                   
1
rem
;

$form-range-thumb-height
:
                  
$form-range-thumb-width
;

$form-range-thumb-bg
:
                      
$component-active-bg
;

$form-range-thumb-border
:
                  
0
;

$form-range-thumb-border-radius
:
           
1
rem
;

$form-range-thumb-box-shadow
:
              
0
 
.1
rem
 
.25
rem
 
rgba
(
$black
,
 
.1
);

$form-range-thumb-focus-box-shadow
:
        
0
 
0
 
0
 
1
px
 
$body-bg
,
 
$input-focus-box-shadow
;

$form-range-thumb-focus-box-shadow-width
:
  
$input-focus-width
;
 
// For focus box shadow issue in Edge

$form-range-thumb-active-bg
:
               
tint-color
(
$component-active-bg
,
 
70
%
);

$form-range-thumb-disabled-bg
:
             
var
(
--
#{
$prefix
}
secondary-color
);

$form-range-thumb-transition
:
              
background-color
 
.15
s
 
ease-in-out
,
 
border-color
 
.15
s
 
ease-in-out
,
 
box-shadow
 
.15
s
 
ease-in-out
;
```
