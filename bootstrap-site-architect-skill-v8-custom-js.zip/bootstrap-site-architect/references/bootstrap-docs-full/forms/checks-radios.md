# Checks & radios

Source: Bootstrap offline docs `/docs/5.3/forms/checks-radios/` extracted from the user-provided documentation archive.

Official page title: **Checks and radios**.

Lead: Create consistent cross-browser and cross-device checkboxes and radios with our completely rewritten checks component.

### Approach

Browser default checkboxes and radios are replaced with the help of `.form-check`, a series of classes for both input types that improves the layout and behavior of their HTML elements, that provide greater customization and cross browser consistency. Checkboxes are for selecting one or several options in a list, while radios are for selecting one option from many.

Structurally, our `<input>`s and `<label>`s are sibling elements as opposed to an `<input>` within a `<label>`. This is slightly more verbose as you must specify `id` and `for` attributes to relate the `<input>` and `<label>`. We use the sibling selector (`~`) for all our `<input>` states, like `:checked` or `:disabled`. When combined with the `.form-check-label` class, we can easily style the text for each item based on the `<input>`’s state.

Our checks use custom Bootstrap icons to indicate checked or indeterminate states.


### Checks

Default checkbox

Checked checkbox

```html
<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"flexCheckDefault"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexCheckDefault"
>

    Default checkbox

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"flexCheckChecked"
 
checked
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexCheckChecked"
>

    Checked checkbox

  
</
label
>

</
div
>
```


#### Indeterminate

Checkboxes can utilize the `:indeterminate` pseudo class when manually set via JavaScript (there is no available HTML attribute for specifying it).

Indeterminate checkbox

```html
<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"flexCheckIndeterminate"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexCheckIndeterminate"
>

    Indeterminate checkbox

  
</
label
>

</
div
>
```


#### Disabled

Add the `disabled` attribute and the associated `<label>`s are automatically styled to match with a lighter color to help indicate the input’s state.

Disabled indeterminate checkbox

Disabled checkbox

Disabled checked checkbox

```html
<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"flexCheckIndeterminateDisabled"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexCheckIndeterminateDisabled"
>

    Disabled indeterminate checkbox

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"flexCheckDisabled"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexCheckDisabled"
>

    Disabled checkbox

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"flexCheckCheckedDisabled"
 
checked
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexCheckCheckedDisabled"
>

    Disabled checked checkbox

  
</
label
>

</
div
>
```


### Radios

Default radio

Default checked radio

```html
<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"flexRadioDefault"
 
id
=
"flexRadioDefault1"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexRadioDefault1"
>

    Default radio

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"flexRadioDefault"
 
id
=
"flexRadioDefault2"
 
checked
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexRadioDefault2"
>

    Default checked radio

  
</
label
>

</
div
>
```


#### Disabled

Add the `disabled` attribute and the associated `<label>`s are automatically styled to match with a lighter color to help indicate the input’s state.

Disabled radio

Disabled checked radio

```html
<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"flexRadioDisabled"
 
id
=
"flexRadioDisabled"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexRadioDisabled"
>

    Disabled radio

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"flexRadioDisabled"
 
id
=
"flexRadioCheckedDisabled"
 
checked
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexRadioCheckedDisabled"
>

    Disabled checked radio

  
</
label
>

</
div
>
```


### Switches

A switch has the markup of a custom checkbox but uses the `.form-switch` class to render a toggle switch. Consider using `role="switch"` to more accurately convey the nature of the control to assistive technologies that support this role. In older assistive technologies, it will simply be announced as a regular checkbox as a fallback. Switches also support the `disabled` attribute.

Default switch checkbox input

Checked switch checkbox input

Disabled switch checkbox input

Disabled checked switch checkbox input

```html
<
div
 
class
=
"form-check form-switch"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
role
=
"switch"
 
id
=
"flexSwitchCheckDefault"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexSwitchCheckDefault"
>
Default switch checkbox input
</
label
>

</
div
>

<
div
 
class
=
"form-check form-switch"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
role
=
"switch"
 
id
=
"flexSwitchCheckChecked"
 
checked
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexSwitchCheckChecked"
>
Checked switch checkbox input
</
label
>

</
div
>

<
div
 
class
=
"form-check form-switch"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
role
=
"switch"
 
id
=
"flexSwitchCheckDisabled"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexSwitchCheckDisabled"
>
Disabled switch checkbox input
</
label
>

</
div
>

<
div
 
class
=
"form-check form-switch"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
role
=
"switch"
 
id
=
"flexSwitchCheckCheckedDisabled"
 
checked
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexSwitchCheckCheckedDisabled"
>
Disabled checked switch checkbox input
</
label
>

</
div
>
```


### Default (stacked)

By default, any number of checkboxes and radios that are immediate sibling will be vertically stacked and appropriately spaced with `.form-check`.

Default checkbox

Disabled checkbox

```html
<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"defaultCheck1"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"defaultCheck1"
>

    Default checkbox

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"defaultCheck2"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"defaultCheck2"
>

    Disabled checkbox

  
</
label
>

</
div
>
```

Default radio

Second default radio

Disabled radio

```html
<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"exampleRadios"
 
id
=
"exampleRadios1"
 
value
=
"option1"
 
checked
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"exampleRadios1"
>

    Default radio

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"exampleRadios"
 
id
=
"exampleRadios2"
 
value
=
"option2"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"exampleRadios2"
>

    Second default radio

  
</
label
>

</
div
>

<
div
 
class
=
"form-check"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"exampleRadios"
 
id
=
"exampleRadios3"
 
value
=
"option3"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"exampleRadios3"
>

    Disabled radio

  
</
label
>

</
div
>
```


### Inline

Group checkboxes or radios on the same horizontal row by adding `.form-check-inline` to any `.form-check`.

1

2

3 (disabled)

```html
<
div
 
class
=
"form-check form-check-inline"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
id
=
"inlineCheckbox1"
 
value
=
"option1"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"inlineCheckbox1"
>
1
</
label
>

</
div
>

<
div
 
class
=
"form-check form-check-inline"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
id
=
"inlineCheckbox2"
 
value
=
"option2"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"inlineCheckbox2"
>
2
</
label
>

</
div
>

<
div
 
class
=
"form-check form-check-inline"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
id
=
"inlineCheckbox3"
 
value
=
"option3"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"inlineCheckbox3"
>
3 (disabled)
</
label
>

</
div
>
```

1

2

3 (disabled)

```html
<
div
 
class
=
"form-check form-check-inline"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"inlineRadioOptions"
 
id
=
"inlineRadio1"
 
value
=
"option1"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"inlineRadio1"
>
1
</
label
>

</
div
>

<
div
 
class
=
"form-check form-check-inline"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"inlineRadioOptions"
 
id
=
"inlineRadio2"
 
value
=
"option2"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"inlineRadio2"
>
2
</
label
>

</
div
>

<
div
 
class
=
"form-check form-check-inline"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"inlineRadioOptions"
 
id
=
"inlineRadio3"
 
value
=
"option3"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"inlineRadio3"
>
3 (disabled)
</
label
>

</
div
>
```


### Reverse

Put your checkboxes, radios, and switches on the opposite side with the `.form-check-reverse` modifier class.

Reverse checkbox

Disabled reverse checkbox

Reverse switch checkbox input

```html
<
div
 
class
=
"form-check form-check-reverse"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"reverseCheck1"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"reverseCheck1"
>

    Reverse checkbox

  
</
label
>

</
div
>

<
div
 
class
=
"form-check form-check-reverse"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
value
=
""
 
id
=
"reverseCheck2"
 
disabled
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"reverseCheck2"
>

    Disabled reverse checkbox

  
</
label
>

</
div
>

<
div
 
class
=
"form-check form-switch form-check-reverse"
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
id
=
"flexSwitchCheckReverse"
>

  
<
label
 
class
=
"form-check-label"
 
for
=
"flexSwitchCheckReverse"
>
Reverse switch checkbox input
</
label
>

</
div
>
```


### Without labels

Omit the wrapping `.form-check` for checkboxes and radios that have no label text. Remember to still provide some form of accessible name for assistive technologies (for instance, using `aria-label`). See the forms overview accessibility section for details.

```html
<
div
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"checkbox"
 
id
=
"checkboxNoLabel"
 
value
=
""
 
aria-label
=
"..."
>

</
div
>

<
div
>

  
<
input
 
class
=
"form-check-input"
 
type
=
"radio"
 
name
=
"radioNoLabel"
 
id
=
"radioNoLabel1"
 
value
=
""
 
aria-label
=
"..."
>

</
div
>
```


### Toggle buttons

Create button-like checkboxes and radio buttons by using `.btn` styles rather than `.form-check-label` on the `<label>` elements. These toggle buttons can further be grouped in a button group if needed.


#### Checkbox toggle buttons

Single toggle

```html
<
input
 
type
=
"checkbox"
 
class
=
"btn-check"
 
id
=
"btn-check"
 
autocomplete
=
"off"
>

<
label
 
class
=
"btn btn-primary"
 
for
=
"btn-check"
>
Single toggle
</
label
>
```

Checked

```html
<
input
 
type
=
"checkbox"
 
class
=
"btn-check"
 
id
=
"btn-check-2"
 
checked
 
autocomplete
=
"off"
>

<
label
 
class
=
"btn btn-primary"
 
for
=
"btn-check-2"
>
Checked
</
label
>
```

Disabled

```html
<
input
 
type
=
"checkbox"
 
class
=
"btn-check"
 
id
=
"btn-check-3"
 
autocomplete
=
"off"
 
disabled
>

<
label
 
class
=
"btn btn-primary"
 
for
=
"btn-check-3"
>
Disabled
</
label
>
```

> Note: Visually, these checkbox toggle buttons are identical to the

button plugin toggle buttons

. However, they are conveyed differently by assistive technologies: the checkbox toggles will be announced by screen readers as “checked”/“not checked” (since, despite their appearance, they are fundamentally still checkboxes), whereas the button plugin toggle buttons will be announced as “button”/“button pressed”. The choice between these two approaches will depend on the type of toggle you are creating, and whether or not the toggle will make sense to users when announced as a checkbox or as an actual button.


#### Radio toggle buttons

Checked

Radio

Disabled

Radio

```html
<
input
 
type
=
"radio"
 
class
=
"btn-check"
 
name
=
"options"
 
id
=
"option1"
 
autocomplete
=
"off"
 
checked
>

<
label
 
class
=
"btn btn-secondary"
 
for
=
"option1"
>
Checked
</
label
>

<
input
 
type
=
"radio"
 
class
=
"btn-check"
 
name
=
"options"
 
id
=
"option2"
 
autocomplete
=
"off"
>

<
label
 
class
=
"btn btn-secondary"
 
for
=
"option2"
>
Radio
</
label
>

<
input
 
type
=
"radio"
 
class
=
"btn-check"
 
name
=
"options"
 
id
=
"option3"
 
autocomplete
=
"off"
 
disabled
>

<
label
 
class
=
"btn btn-secondary"
 
for
=
"option3"
>
Disabled
</
label
>

<
input
 
type
=
"radio"
 
class
=
"btn-check"
 
name
=
"options"
 
id
=
"option4"
 
autocomplete
=
"off"
>

<
label
 
class
=
"btn btn-secondary"
 
for
=
"option4"
>
Radio
</
label
>
```


#### Outlined styles

Different variants of `.btn`, such at the various outlined styles, are supported.

Single toggle

Checked

Checked success radio

Danger radio

```html
<
input
 
type
=
"checkbox"
 
class
=
"btn-check"
 
id
=
"btn-check-outlined"
 
autocomplete
=
"off"
>

<
label
 
class
=
"btn btn-outline-primary"
 
for
=
"btn-check-outlined"
>
Single toggle
</
label
><
br
>

<
input
 
type
=
"checkbox"
 
class
=
"btn-check"
 
id
=
"btn-check-2-outlined"
 
checked
 
autocomplete
=
"off"
>

<
label
 
class
=
"btn btn-outline-secondary"
 
for
=
"btn-check-2-outlined"
>
Checked
</
label
><
br
>

<
input
 
type
=
"radio"
 
class
=
"btn-check"
 
name
=
"options-outlined"
 
id
=
"success-outlined"
 
autocomplete
=
"off"
 
checked
>

<
label
 
class
=
"btn btn-outline-success"
 
for
=
"success-outlined"
>
Checked success radio
</
label
>

<
input
 
type
=
"radio"
 
class
=
"btn-check"
 
name
=
"options-outlined"
 
id
=
"danger-outlined"
 
autocomplete
=
"off"
>

<
label
 
class
=
"btn btn-outline-danger"
 
for
=
"danger-outlined"
>
Danger radio
</
label
>
```


### CSS


#### Sass variables

Variables for checks:

```scss
$form-check-input-width
:
                  
1
em
;

$form-check-min-height
:
                   
$font-size-base
 
*
 
$line-height-base
;

$form-check-padding-start
:
                
$form-check-input-width
 
+
 
.5
em
;

$form-check-margin-bottom
:
                
.125
rem
;

$form-check-label-color
:
                  
null
;

$form-check-label-cursor
:
                 
null
;

$form-check-transition
:
                   
null
;

$form-check-input-active-filter
:
          
brightness
(
90
%
);

$form-check-input-bg
:
                     
$input-bg
;

$form-check-input-border
:
                 
var
(
--
#{
$prefix
}
border-width
)
 
solid
 
var
(
--
#{
$prefix
}
border-color
);

$form-check-input-border-radius
:
          
.25
em
;

$form-check-radio-border-radius
:
          
50
%
;

$form-check-input-focus-border
:
           
$input-focus-border-color
;

$form-check-input-focus-box-shadow
:
       
$focus-ring-box-shadow
;

$form-check-input-checked-color
:
          
$component-active-color
;

$form-check-input-checked-bg-color
:
       
$component-active-bg
;

$form-check-input-checked-border-color
:
   
$form-check-input-checked-bg-color
;

$form-check-input-checked-bg-image
:
       
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'><path fill='none' stroke='
#{
$form-check-input-checked-color
}
' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='m6 10 3 3 6-6'/></svg>")
;

$form-check-radio-checked-bg-image
:
       
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'><circle r='2' fill='
#{
$form-check-input-checked-color
}
'/></svg>")
;

$form-check-input-indeterminate-color
:
          
$component-active-color
;

$form-check-input-indeterminate-bg-color
:
       
$component-active-bg
;

$form-check-input-indeterminate-border-color
:
   
$form-check-input-indeterminate-bg-color
;

$form-check-input-indeterminate-bg-image
:
       
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'><path fill='none' stroke='
#{
$form-check-input-indeterminate-color
}
' stroke-linecap='round' stroke-linejoin='round' stroke-width='3' d='M6 10h8'/></svg>")
;

$form-check-input-disabled-opacity
:
        
.5
;

$form-check-label-disabled-opacity
:
        
$form-check-input-disabled-opacity
;

$form-check-btn-check-disabled-opacity
:
    
$btn-disabled-opacity
;

$form-check-inline-margin-end
:
    
1
rem
;
```

Variables for switches:

```scss
$form-switch-color
:
               
rgba
(
$black
,
 
.25
);

$form-switch-width
:
               
2
em
;

$form-switch-padding-start
:
       
$form-switch-width
 
+
 
.5
em
;

$form-switch-bg-image
:
            
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'><circle r='3' fill='
#{
$form-switch-color
}
'/></svg>")
;

$form-switch-border-radius
:
       
$form-switch-width
;

$form-switch-transition
:
          
background-position
 
.15
s
 
ease-in-out
;

$form-switch-focus-color
:
         
$input-focus-border-color
;

$form-switch-focus-bg-image
:
      
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'><circle r='3' fill='
#{
$form-switch-focus-color
}
'/></svg>")
;

$form-switch-checked-color
:
       
$component-active-color
;

$form-switch-checked-bg-image
:
    
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'><circle r='3' fill='
#{
$form-switch-checked-color
}
'/></svg>")
;

$form-switch-checked-bg-position
:
 
right
 
center
;
```
