# Shadows

Source: Bootstrap offline docs `/docs/5.3/utilities/shadows/` extracted from the user-provided documentation archive.

Lead: Add or remove shadows to elements with box-shadow utilities.

### Examples

While shadows on components are disabled by default in Bootstrap and can be enabled via `$enable-shadows`, you can also quickly add or remove a shadow with our `box-shadow` utility classes. Includes support for `.shadow-none` and three default sizes (which have associated variables to match).

No shadow

Small shadow

Regular shadow

Larger shadow

```html
<
div
 
class
=
"shadow-none p-3 mb-5 bg-body-tertiary rounded"
>
No shadow
</
div
>

<
div
 
class
=
"shadow-sm p-3 mb-5 bg-body-tertiary rounded"
>
Small shadow
</
div
>

<
div
 
class
=
"shadow p-3 mb-5 bg-body-tertiary rounded"
>
Regular shadow
</
div
>

<
div
 
class
=
"shadow-lg p-3 mb-5 bg-body-tertiary rounded"
>
Larger shadow
</
div
>
```


### Sass


#### Variables

```scss
$box-shadow
:
                  
0
 
.5
rem
 
1
rem
 
rgba
(
$black
,
 
.15
);

$box-shadow-sm
:
               
0
 
.125
rem
 
.25
rem
 
rgba
(
$black
,
 
.075
);

$box-shadow-lg
:
               
0
 
1
rem
 
3
rem
 
rgba
(
$black
,
 
.175
);

$box-shadow-inset
:
            
inset
 
0
 
1
px
 
2
px
 
rgba
(
$black
,
 
.075
);
```


#### Utilities API

Shadow utilities are declared in our utilities API in `scss/_utilities.scss`. Learn how to use the utilities API.

```scss
"shadow"
:
 
(

  
property
:
 
box-shadow
,

  
class
:
 
shadow
,

  
values
:
 
(

    
null
:
 
$
box-shadow
,

    
sm
:
 
$
box-shadow-sm
,

    
lg
:
 
$
box-shadow-lg
,

    
none
:
 
none
,

  
)

),
```
