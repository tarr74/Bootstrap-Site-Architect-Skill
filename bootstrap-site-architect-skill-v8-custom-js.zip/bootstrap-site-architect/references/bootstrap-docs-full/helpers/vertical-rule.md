# Vertical rule

Source: Bootstrap offline docs `/docs/5.3/helpers/vertical-rule/` extracted from the user-provided documentation archive.

Lead: Use the custom vertical rule helper to create vertical dividers like the <hr> element.

### How it works

Vertical rules are inspired by the `<hr>` element, allowing you to create vertical dividers in common layouts. They’re styled just like `<hr>` elements:

- They’re `1px` wide
- They have `min-height` of `1em`
- Their color is set via `currentColor` and
                `opacity`

Customize them with additional styles as needed.


### Example

```html
<
div
 
class
=
"vr"
></
div
>
```

Vertical rules scale their height in flex layouts:

```html
<
div
 
class
=
"d-flex"
 
style
=
"height: 200px;"
>

  
<
div
 
class
=
"vr"
></
div
>

</
div
>
```


### With stacks

They can also be used in stacks:

First item

Second item

Third item

```html
<
div
 
class
=
"hstack gap-3"
>

  
<
div
 
class
=
"p-2"
>
First item
</
div
>

  
<
div
 
class
=
"p-2 ms-auto"
>
Second item
</
div
>

  
<
div
 
class
=
"vr"
></
div
>

  
<
div
 
class
=
"p-2"
>
Third item
</
div
>

</
div
>
```
