# Ratio

Source: Bootstrap offline docs `/docs/5.3/helpers/ratio/` extracted from the user-provided documentation archive.

Official page title: **Ratios**.

Lead: Use generated pseudo elements to make an element maintain the aspect ratio of your choosing. Perfect for responsively handling video or slideshow embeds based on the width of the parent.

### About

Use the ratio helper to manage the aspect ratios of external content like `<iframe>`s, `<embed>`s, `<video>`s, and `<object>`s. These helpers also can be used on any standard HTML child element (e.g., a `<div>` or `<img>`). Styles are applied from the parent `.ratio` class directly to the child.

Aspect ratios are declared in a Sass map and included in each class via CSS variable, which also allows custom aspect ratios.

> Note: Pro-Tip!

You don’t need

frameborder="0"

on your

<iframe>

s as we override that for you in

Reboot

.


### Example

Wrap any embed, like an `<iframe>`, in a parent element with `.ratio` and an aspect ratio class. The immediate child element is automatically sized thanks to our universal selector `.ratio > *`.

```html
<
div
 
class
=
"ratio ratio-16x9"
>

  
<
iframe
 
src
=
"https://www.youtube.com/embed/zpOULjyy-n8?rel=0"
 
title
=
"YouTube video"
 
allowfullscreen
></
iframe
>

</
div
>
```


### Aspect ratios

Aspect ratios can be customized with modifier classes. By default the following ratio classes are provided:

1x1

4x3

16x9

21x9

```html
<
div
 
class
=
"ratio ratio-1x1"
>

  
<
div
>
1x1
</
div
>

</
div
>

<
div
 
class
=
"ratio ratio-4x3"
>

  
<
div
>
4x3
</
div
>

</
div
>

<
div
 
class
=
"ratio ratio-16x9"
>

  
<
div
>
16x9
</
div
>

</
div
>

<
div
 
class
=
"ratio ratio-21x9"
>

  
<
div
>
21x9
</
div
>

</
div
>
```


### Custom ratios

Each `.ratio-*` class includes a CSS custom property (or CSS variable) in the selector. You can override this CSS variable to create custom aspect ratios on the fly with some quick math on your part.

For example, to create a 2x1 aspect ratio, set `--bs-aspect-ratio: 50%` on the `.ratio`.

2x1

```html
<
div
 
class
=
"ratio"
 
style
=
"--bs-aspect-ratio: 50%;"
>

  
<
div
>
2x1
</
div
>

</
div
>
```

This CSS variable makes it easy to modify the aspect ratio across breakpoints. The following is 4x3 to start, but changes to a custom 2x1 at the medium breakpoint.

```scss
.ratio-4x3
 
{

  
@include
 media-breakpoint-up
(
md
)
 
{

    
--bs-aspect-ratio
:
 
50
%
;
 
// 2x1

  
}

}
```

4x3, then 2x1

```html
<
div
 
class
=
"ratio ratio-4x3"
>

  
<
div
>
4x3, then 2x1
</
div
>

</
div
>
```


### Sass map

Within `_variables.scss`, you can change the aspect ratios you want to use. Here’s our default `$ratio-aspect-ratios` map. Modify the map as you like and recompile your Sass to put them to use.

```scss
$aspect-ratios
:
 
(

  
"1x1"
:
 
100
%
,

  
"4x3"
:
 
calc
(
3
 
/
 
4
 
*
 
100
%
)
,

  
"16x9"
:
 
calc
(
9
 
/
 
16
 
*
 
100
%
)
,

  
"21x9"
:
 
calc
(
9
 
/
 
21
 
*
 
100
%
)

);
```
