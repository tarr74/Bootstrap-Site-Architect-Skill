# Close button

Source: Bootstrap offline docs `/docs/5.3/components/close-button/` extracted from the user-provided documentation archive.

Lead: A generic close button for dismissing content like modals and alerts.

### Example

Provide an option to dismiss or close a component with `.btn-close`. Default styling is limited, but highly customizable. Modify the Sass variables to replace the default `background-image`. **Be sure to include text for screen readers**, as we’ve done with `aria-label`.

```html
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
aria-label
=
"Close"
></
button
>
```


### Disabled state

Disabled close buttons change their `opacity`. We’ve also applied `pointer-events: none` and `user-select: none` to preventing hover and active states from triggering.

```html
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
disabled
 
aria-label
=
"Close"
></
button
>
```


### Dark variant

Deprecated in v5.3.0

> Note: Heads up!

As of v5.3.0, the

.btn-close-white

class is deprecated. Instead, use

data-bs-theme="dark"

to change the color mode of the close button.

Add `data-bs-theme="dark"` to the `.btn-close`, or to its parent element, to invert the close button. This uses the `filter` property to invert the `background-image` without overriding its value.

```html
<
div
 
data-bs-theme
=
"dark"
>

  
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
aria-label
=
"Close"
></
button
>

  
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
disabled
 
aria-label
=
"Close"
></
button
>

</
div
>
```


### CSS


#### Variables

Added in v5.3.0

As part of Bootstrap’s evolving CSS variables approach, close button now uses local CSS variables on `.btn-close` for enhanced real-time customization. Values for the CSS variables are set via Sass, so Sass customization is still supported, too.

```scss
--#{$prefix}btn-close-color
:
 
#{
$btn-close-color
}
;

--#{$prefix}btn-close-bg
:
 
#{
 
escape-svg
(
$btn-close-bg
)
 
}
;

--#{$prefix}btn-close-opacity
:
 
#{
$btn-close-opacity
}
;

--#{$prefix}btn-close-hover-opacity
:
 
#{
$btn-close-hover-opacity
}
;

--#{$prefix}btn-close-focus-shadow
:
 
#{
$btn-close-focus-shadow
}
;

--#{$prefix}btn-close-focus-opacity
:
 
#{
$btn-close-focus-opacity
}
;

--#{$prefix}btn-close-disabled-opacity
:
 
#{
$btn-close-disabled-opacity
}
;

--#{$prefix}btn-close-white-filter
:
 
#{
$btn-close-white-filter
}
;
```


#### Sass variables

```scss
$btn-close-width
:
            
1
em
;

$btn-close-height
:
           
$btn-close-width
;

$btn-close-padding-x
:
        
.25
em
;

$btn-close-padding-y
:
        
$btn-close-padding-x
;

$btn-close-color
:
            
$black
;

$btn-close-bg
:
               
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='
#{
$btn-close-color
}
'><path d='M.293.293a1 1 0 0 1 1.414 0L8 6.586 14.293.293a1 1 0 1 1 1.414 1.414L9.414 8l6.293 6.293a1 1 0 0 1-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L6.586 8 .293 1.707a1 1 0 0 1 0-1.414z'/></svg>")
;

$btn-close-focus-shadow
:
     
$focus-ring-box-shadow
;

$btn-close-opacity
:
          
.5
;

$btn-close-hover-opacity
:
    
.75
;

$btn-close-focus-opacity
:
    
1
;

$btn-close-disabled-opacity
:
 
.25
;

$btn-close-white-filter
:
     
invert
(
1
)
 
grayscale
(
100
%
)
 
brightness
(
200
%
);
```
