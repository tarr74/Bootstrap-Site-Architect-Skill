# Toasts

Source: Bootstrap offline docs `/docs/5.3/components/toasts/` extracted from the user-provided documentation archive.

Lead: Push notifications to your visitors with a toast, a lightweight and easily customizable alert message.

Toasts are lightweight notifications designed to mimic the push notifications that have been popularized by mobile and desktop operating systems. They’re built with flexbox, so they’re easy to align and position.


### Overview

Things to know when using the toast plugin:

- Toasts are opt-in for performance reasons, so
                **you must initialize them yourself**.
- Toasts will automatically hide if you do not specify
                `autohide: false`.

> Note: The animation effect of this component is dependent on the

prefers-reduced-motion

media query. See the

reduced motion section of our accessibility documentation

.


### Examples


#### Basic

To encourage extensible and predictable toasts, we recommend a header and body. Toast headers use `display: flex`, allowing easy alignment of content thanks to our margin and flexbox utilities.

Toasts are as flexible as you need and have very little required markup. At a minimum, we require a single element to contain your “toasted” content and strongly encourage a dismiss button.

Bootstrap

11 mins ago

Hello, world! This is a toast message.

```html
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

  
<
div
 
class
=
"toast-header"
>

    
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

    
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

    
<
small
>
11 mins ago
</
small
>

    
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

  
</
div
>

  
<
div
 
class
=
"toast-body"
>

    Hello, world! This is a toast message.

  
</
div
>

</
div
>
```

> Note: Previously, our scripts dynamically added the

.hide

class to completely hide a toast (with

display:none

, rather than just with

opacity:0

). This is now not necessary anymore. However, for backwards compatibility, our script will continue to toggle the class (even though there is no practical need for it) until the next major version.


#### Live example

Click the button below to show a toast (positioned with our utilities in the lower right corner) that has been hidden by default.

Bootstrap

11 mins ago

Hello, world! This is a toast message.

```html
<
button
 
type
=
"button"
 
class
=
"btn btn-primary"
 
id
=
"liveToastBtn"
>
Show live toast
</
button
>

<
div
 
class
=
"toast-container position-fixed bottom-0 end-0 p-3"
>

  
<
div
 
id
=
"liveToast"
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

    
<
div
 
class
=
"toast-header"
>

      
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

      
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

      
<
small
>
11 mins ago
</
small
>

      
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

    
</
div
>

    
<
div
 
class
=
"toast-body"
>

      Hello, world! This is a toast message.

    
</
div
>

  
</
div
>

</
div
>
```

We use the following JavaScript to trigger our live toast demo:

```js
const
 
toastTrigger
 
=
 
document
.
getElementById
(
'liveToastBtn'
)

const
 
toastLiveExample
 
=
 
document
.
getElementById
(
'liveToast'
)

if
 
(
toastTrigger
)
 
{

  
const
 
toastBootstrap
 
=
 
bootstrap
.
Toast
.
getOrCreateInstance
(
toastLiveExample
)

  
toastTrigger
.
addEventListener
(
'click'
,
 
()
 
=>
 
{

    
toastBootstrap
.
show
()

  
})

}
```


#### Translucent

Toasts are slightly translucent to blend in with what’s below them.

Bootstrap

11 mins ago

Hello, world! This is a toast message.

```html
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

  
<
div
 
class
=
"toast-header"
>

    
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

    
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

    
<
small
 
class
=
"text-body-secondary"
>
11 mins ago
</
small
>

    
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

  
</
div
>

  
<
div
 
class
=
"toast-body"
>

    Hello, world! This is a toast message.

  
</
div
>

</
div
>
```


#### Stacking

You can stack toasts by wrapping them in a toast container, which will vertically add some spacing.

Bootstrap

just now

See? Just like this.

Bootstrap

2 seconds ago

Heads up, toasts will stack automatically

```html
<
div
 
class
=
"toast-container position-static"
>

  
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

    
<
div
 
class
=
"toast-header"
>

      
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

      
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

      
<
small
 
class
=
"text-body-secondary"
>
just now
</
small
>

      
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

    
</
div
>

    
<
div
 
class
=
"toast-body"
>

      See? Just like this.

    
</
div
>

  
</
div
>

  
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

    
<
div
 
class
=
"toast-header"
>

      
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

      
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

      
<
small
 
class
=
"text-body-secondary"
>
2 seconds ago
</
small
>

      
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

    
</
div
>

    
<
div
 
class
=
"toast-body"
>

      Heads up, toasts will stack automatically

    
</
div
>

  
</
div
>

</
div
>
```


#### Custom content

Customize your toasts by removing sub-components, tweaking them with utilities, or by adding your own markup. Here we’ve created a simpler toast by removing the default `.toast-header`, adding a custom hide icon from [Bootstrap Icons](https://icons.getbootstrap.com/), and using some flexbox utilities to adjust the layout.

```html
<
div
 
class
=
"toast align-items-center"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

  
<
div
 
class
=
"d-flex"
>

    
<
div
 
class
=
"toast-body"
>

      Hello, world! This is a toast message.

    
</
div
>

    
<
button
 
type
=
"button"
 
class
=
"btn-close me-2 m-auto"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

  
</
div
>

</
div
>
```

Alternatively, you can also add additional controls and components to toasts.

Hello, world! This is a toast message.

```html
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

  
<
div
 
class
=
"toast-body"
>

    Hello, world! This is a toast message.

    
<
div
 
class
=
"mt-2 pt-2 border-top"
>

      
<
button
 
type
=
"button"
 
class
=
"btn btn-primary btn-sm"
>
Take action
</
button
>

      
<
button
 
type
=
"button"
 
class
=
"btn btn-secondary btn-sm"
 
data-bs-dismiss
=
"toast"
>
Close
</
button
>

    
</
div
>

  
</
div
>

</
div
>
```


#### Color schemes

Building on the above example, you can create different toast color schemes with our color and background utilities. Here we’ve added `.text-bg-primary` to the `.toast`, and then added `.btn-close-white` to our close button. For a crisp edge, we remove the default border with `.border-0`.

```html
<
div
 
class
=
"toast align-items-center text-bg-primary border-0"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

  
<
div
 
class
=
"d-flex"
>

    
<
div
 
class
=
"toast-body"
>

      Hello, world! This is a toast message.

    
</
div
>

    
<
button
 
type
=
"button"
 
class
=
"btn-close btn-close-white me-2 m-auto"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

  
</
div
>

</
div
>
```


### Placement

Place toasts with custom CSS as you need them. The top right is often used for notifications, as is the top middle. If you’re only ever going to show one toast at a time, put the positioning styles right on the `.toast`.

Toast placement

Select a position...

Top left

Top center

Top right

Middle left

Middle center

Middle right

Bottom left

Bottom center

Bottom right

Bootstrap

11 mins ago

Hello, world! This is a toast message.

```html
<
form
>

  
<
div
 
class
=
"mb-3"
>

    
<
label
 
for
=
"selectToastPlacement"
>
Toast placement
</
label
>

    
<
select
 
class
=
"form-select mt-2"
 
id
=
"selectToastPlacement"
>

      
<
option
 
value
=
""
 
selected
>
Select a position...
</
option
>

      
<
option
 
value
=
"top-0 start-0"
>
Top left
</
option
>

      
<
option
 
value
=
"top-0 start-50 translate-middle-x"
>
Top center
</
option
>

      
<
option
 
value
=
"top-0 end-0"
>
Top right
</
option
>

      
<
option
 
value
=
"top-50 start-0 translate-middle-y"
>
Middle left
</
option
>

      
<
option
 
value
=
"top-50 start-50 translate-middle"
>
Middle center
</
option
>

      
<
option
 
value
=
"top-50 end-0 translate-middle-y"
>
Middle right
</
option
>

      
<
option
 
value
=
"bottom-0 start-0"
>
Bottom left
</
option
>

      
<
option
 
value
=
"bottom-0 start-50 translate-middle-x"
>
Bottom center
</
option
>

      
<
option
 
value
=
"bottom-0 end-0"
>
Bottom right
</
option
>

    
</
select
>

  
</
div
>

</
form
>

<
div
 
aria-live
=
"polite"
 
aria-atomic
=
"true"
 
class
=
"bg-body-secondary position-relative bd-example-toasts rounded-3"
>

  
<
div
 
class
=
"toast-container p-3"
 
id
=
"toastPlacement"
>

    
<
div
 
class
=
"toast"
>

      
<
div
 
class
=
"toast-header"
>

        
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

        
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

        
<
small
>
11 mins ago
</
small
>

      
</
div
>

      
<
div
 
class
=
"toast-body"
>

        Hello, world! This is a toast message.

      
</
div
>

    
</
div
>

  
</
div
>

</
div
>
```

For systems that generate more notifications, consider using a wrapping element so they can easily stack.

Position it:

- `.toast-container` for spacing between toasts

- `top-0` & `end-0` to position the toasts in the upper right corner

- `.p-3` to prevent the toasts from sticking to the edge of the container

Then put toasts within

Bootstrap

just now

See? Just like this.

Bootstrap

2 seconds ago

Heads up, toasts will stack automatically

```html
<
div
 
aria-live
=
"polite"
 
aria-atomic
=
"true"
 
class
=
"position-relative"
>

  
<!-- Position it: -->

  
<!-- - `.toast-container` for spacing between toasts -->

  
<!-- - `top-0` & `end-0` to position the toasts in the upper right corner -->

  
<!-- - `.p-3` to prevent the toasts from sticking to the edge of the container  -->

  
<
div
 
class
=
"toast-container top-0 end-0 p-3"
>

    
<!-- Then put toasts within -->

    
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

      
<
div
 
class
=
"toast-header"
>

        
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

        
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

        
<
small
 
class
=
"text-body-secondary"
>
just now
</
small
>

        
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

      
</
div
>

      
<
div
 
class
=
"toast-body"
>

        See? Just like this.

      
</
div
>

    
</
div
>

    
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

      
<
div
 
class
=
"toast-header"
>

        
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

        
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

        
<
small
 
class
=
"text-body-secondary"
>
2 seconds ago
</
small
>

        
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

      
</
div
>

      
<
div
 
class
=
"toast-body"
>

        Heads up, toasts will stack automatically

      
</
div
>

    
</
div
>

  
</
div
>

</
div
>
```

You can also get fancy with flexbox utilities to align toasts horizontally and/or vertically.

```html
<!-- Flexbox container for aligning the toasts -->

<
div
 
aria-live
=
"polite"
 
aria-atomic
=
"true"
 
class
=
"d-flex justify-content-center align-items-center w-100"
>

  
<!-- Then put toasts within -->

  
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>

    
<
div
 
class
=
"toast-header"
>

      
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

      
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

      
<
small
>
11 mins ago
</
small
>

      
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

    
</
div
>

    
<
div
 
class
=
"toast-body"
>

      Hello, world! This is a toast message.

    
</
div
>

  
</
div
>

</
div
>
```


### Accessibility

Toasts are intended to be small interruptions to your visitors or users, so to help those with screen readers and similar assistive technologies, you should wrap your toasts in an [`aria-live` region](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/ARIA_Live_Regions). Changes to live regions (such as injecting/updating a toast component) are automatically announced by screen readers without needing to move the user’s focus or otherwise interrupt the user. Additionally, include `aria-atomic="true"` to ensure that the entire toast is always announced as a single (atomic) unit, rather than just announcing what was changed (which could lead to problems if you only update part of the toast’s content, or if displaying the same toast content at a later point in time). If the information needed is important for the process, e.g. for a list of errors in a form, then use the alert component instead of toast.

Note that the live region needs to be present in the markup *before* the toast is generated or updated. If you dynamically generate both at the same time and inject them into the page, they will generally not be announced by assistive technologies.

You also need to adapt the `role` and `aria-live` level depending on the content. If it’s an important message like an error, use `role="alert" aria-live="assertive"`, otherwise use `role="status" aria-live="polite"` attributes.

As the content you’re displaying changes, be sure to update the `delay` timeout so that users have enough time to read the toast.

```html
<
div
 
class
=
"toast"
 
role
=
"alert"
 
aria-live
=
"polite"
 
aria-atomic
=
"true"
 
data-bs-delay
=
"10000"
>

  
<
div
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
>
...
</
div
>

</
div
>
```

When using `autohide: false`, you must add a close button to allow users to dismiss the toast.

Bootstrap

11 mins ago

Hello, world! This is a toast message.

```html
<
div
 
role
=
"alert"
 
aria-live
=
"assertive"
 
aria-atomic
=
"true"
 
class
=
"toast"
 
data-bs-autohide
=
"false"
>

  
<
div
 
class
=
"toast-header"
>

    
<
img
 
src
=
"..."
 
class
=
"rounded me-2"
 
alt
=
"..."
>

    
<
strong
 
class
=
"me-auto"
>
Bootstrap
</
strong
>

    
<
small
>
11 mins ago
</
small
>

    
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>

  
</
div
>

  
<
div
 
class
=
"toast-body"
>

    Hello, world! This is a toast message.

  
</
div
>

</
div
>
```

While technically it’s possible to add focusable/actionable controls (such as additional buttons or links) in your toast, you should avoid doing this for autohiding toasts. Even if you give the toast a long `delay` timeout, keyboard and assistive technology users may find it difficult to reach the toast in time to take action (since toasts don’t receive focus when they are displayed). If you absolutely must have further controls, we recommend using a toast with `autohide: false`.


### CSS


#### Variables

Added in v5.2.0

As part of Bootstrap’s evolving CSS variables approach, toasts now use local CSS variables on `.toast` for enhanced real-time customization. Values for the CSS variables are set via Sass, so Sass customization is still supported, too.

```scss
--#{$prefix}toast-zindex
:
 
#{
$zindex-toast
}
;

--#{$prefix}toast-padding-x
:
 
#{
$toast-padding-x
}
;

--#{$prefix}toast-padding-y
:
 
#{
$toast-padding-y
}
;

--#{$prefix}toast-spacing
:
 
#{
$toast-spacing
}
;

--#{$prefix}toast-max-width
:
 
#{
$toast-max-width
}
;

@include
 rfs
(
$toast-font-size
,
 
--
#{
$prefix
}
toast-font-size
);

--#{$prefix}toast-color
:
 
#{
$toast-color
}
;

--#{$prefix}toast-bg
:
 
#{
$toast-background-color
}
;

--#{$prefix}toast-border-width
:
 
#{
$toast-border-width
}
;

--#{$prefix}toast-border-color
:
 
#{
$toast-border-color
}
;

--#{$prefix}toast-border-radius
:
 
#{
$toast-border-radius
}
;

--#{$prefix}toast-box-shadow
:
 
#{
$toast-box-shadow
}
;

--#{$prefix}toast-header-color
:
 
#{
$toast-header-color
}
;

--#{$prefix}toast-header-bg
:
 
#{
$toast-header-background-color
}
;

--#{$prefix}toast-header-border-color
:
 
#{
$toast-header-border-color
}
;
```


#### Sass variables

```scss
$toast-max-width
:
                   
350
px
;

$toast-padding-x
:
                   
.75
rem
;

$toast-padding-y
:
                   
.5
rem
;

$toast-font-size
:
                   
.875
rem
;

$toast-color
:
                       
null
;

$toast-background-color
:
            
rgba
(
var
(
--
#{
$prefix
}
body-bg-rgb
)
,
 
.85
);

$toast-border-width
:
                
var
(
--
#{
$prefix
}
border-width
);

$toast-border-color
:
                
var
(
--
#{
$prefix
}
border-color-translucent
);

$toast-border-radius
:
               
var
(
--
#{
$prefix
}
border-radius
);

$toast-box-shadow
:
                  
var
(
--
#{
$prefix
}
box-shadow
);

$toast-spacing
:
                     
$container-padding-x
;

$toast-header-color
:
                
var
(
--
#{
$prefix
}
secondary-color
);

$toast-header-background-color
:
     
rgba
(
var
(
--
#{
$prefix
}
body-bg-rgb
)
,
 
.85
);

$toast-header-border-color
:
         
$toast-border-color
;
```


### Usage

Initialize toasts via JavaScript:

```js
const
 
toastElList
 
=
 
document
.
querySelectorAll
(
'.toast'
)

const
 
toastList
 
=
 
[...
toastElList
].
map
(
toastEl
 
=>
 
new
 
bootstrap
.
Toast
(
toastEl
,
 
option
))
```


#### Triggers

Dismissal can be achieved with the `data-bs-dismiss` attribute on a button **within the toast** as demonstrated below:

```html
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
aria-label
=
"Close"
></
button
>
```

or on a button **outside the toast** using the additional `data-bs-target` as demonstrated below:

```html
<
button
 
type
=
"button"
 
class
=
"btn-close"
 
data-bs-dismiss
=
"toast"
 
data-bs-target
=
"#my-toast"
 
aria-label
=
"Close"
></
button
>
```


#### Options

As options can be passed via data attributes or JavaScript, you can append an option name to `data-bs-`, as in `data-bs-animation="{value}"`. Make sure to change the case type of the option name from “*camelCase*” to “*kebab-case*” when passing the options via data attributes. For example, use `data-bs-custom-class="beautifier"` instead of `data-bs-customClass="beautifier"`.

As of Bootstrap 5.2.0, all components support an **experimental** reserved data attribute `data-bs-config` that can house simple component configuration as a JSON string. When an element has `data-bs-config='{"delay":0, "title":123}'` and `data-bs-title="456"` attributes, the final `title` value will be `456` and the separate data attributes will override values given on `data-bs-config`. In addition, existing data attributes are able to house JSON values like `data-bs-delay='{"show":0,"hide":150}'`.

The final configuration object is the merged result of `data-bs-config`, `data-bs-`, and `js object` where the latest given key-value overrides the others.

| Name | Type | Default | Description |
| --- | --- | --- | --- |
| animation | boolean | true | Apply a CSS fade transition to the toast. |
| autohide | boolean | true | Automatically hide the toast after the delay. |
| delay | number | 5000 | Delay in milliseconds before hiding the toast. |


#### Methods

> Note: All API methods are asynchronous and start a transition.

They return to the caller as soon as the transition is started, but before it ends. In addition, a method call on a transitioning component will be ignored.

Learn more in our JavaScript docs.

| Method | Description |
| --- | --- |
| dispose | Hides an element’s toast. Your toast will remain on the DOM but won’t show anymore. |
| getInstance | Static method which allows you to get the toast instance associated with a DOM element. For example: const myToastEl = document.getElementById('myToastEl') const myToast = bootstrap.Toast.getInstance(myToastEl) Returns a Bootstrap toast instance. |
| getOrCreateInstance | Static method which allows you to get the toast instance associated with a DOM element, or create a new one, in case it wasn’t initialized. const myToastEl = document.getElementById('myToastEl') const myToast = bootstrap.Toast.getOrCreateInstance(myToastEl) Returns a Bootstrap toast instance. |
| hide | Hides an element’s toast. Returns to the caller before the toast has actually been hidden (i.e. before the hidden.bs.toast event occurs). You have to manually call this method if you made autohide to false . |
| isShown | Returns a boolean according to toast’s visibility state. |
| show | Reveals an element’s toast. Returns to the caller before the toast has actually been shown (i.e. before the shown.bs.toast event occurs). You have to manually call this method, instead your toast won’t show. |


#### Events

| Event | Description |
| --- | --- |
| hide.bs.toast | This event is fired immediately when the hide instance method has been called. |
| hidden.bs.toast | This event is fired when the toast has finished being hidden from the user. |
| show.bs.toast | This event fires immediately when the show instance method is called. |
| shown.bs.toast | This event is fired when the toast has been made visible to the user. |

```js
const
 
myToastEl
 
=
 
document
.
getElementById
(
'myToast'
)

myToastEl
.
addEventListener
(
'hidden.bs.toast'
,
 
()
 
=>
 
{

  
// do something...

})
```
