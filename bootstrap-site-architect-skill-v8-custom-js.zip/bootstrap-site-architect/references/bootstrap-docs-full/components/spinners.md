# Spinners

Source: Bootstrap offline docs `/docs/5.3/components/spinners/` extracted from the user-provided documentation archive.

Lead: Indicate the loading state of a component or page with Bootstrap spinners, built entirely with HTML, CSS, and no JavaScript.

### About

Bootstrap “spinners” can be used to show the loading state in your projects. They’re built only with HTML and CSS, meaning you don’t need any JavaScript to create them. You will, however, need some custom JavaScript to toggle their visibility. Their appearance, alignment, and sizing can be easily customized with our amazing utility classes.

For accessibility purposes, each loader here includes `role="status"` and a nested `<span class="visually-hidden">Loading...</span>`.

> Note: The animation effect of this component is dependent on the

prefers-reduced-motion

media query. See the

reduced motion section of our accessibility documentation

.


### Border spinner

Use the border spinners for a lightweight loading indicator.

Loading...

```html
<
div
 
class
=
"spinner-border"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>
```


#### Colors

The border spinner uses `currentColor` for its `border-color`, meaning you can customize the color with text color utilities. You can use any of our text color utilities on the standard spinner.

Loading...

Loading...

Loading...

Loading...

Loading...

Loading...

Loading...

Loading...

```html
<
div
 
class
=
"spinner-border text-primary"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-border text-secondary"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-border text-success"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-border text-danger"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-border text-warning"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-border text-info"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-border text-light"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-border text-dark"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>
```

> Note: Why not use

border-color

utilities?

Each border spinner specifies a

transparent

border for at least one side, so

.border-{color}

utilities would override that.


### Growing spinner

If you don’t fancy a border spinner, switch to the grow spinner. While it doesn’t technically spin, it does repeatedly grow!

Loading...

```html
<
div
 
class
=
"spinner-grow"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>
```

Once again, this spinner is built with `currentColor`, so you can easily change its appearance with text color utilities. Here it is in blue, along with the supported variants.

Loading...

Loading...

Loading...

Loading...

Loading...

Loading...

Loading...

Loading...

```html
<
div
 
class
=
"spinner-grow text-primary"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow text-secondary"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow text-success"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow text-danger"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow text-warning"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow text-info"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow text-light"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow text-dark"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>
```


### Alignment

Spinners in Bootstrap are built with `rem`s, `currentColor`, and `display: inline-flex`. This means they can easily be resized, recolored, and quickly aligned.


#### Margin

Use margin utilities like `.m-5` for easy spacing.

Loading...

```html
<
div
 
class
=
"spinner-border m-5"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>
```


#### Placement

Use flexbox utilities, float utilities, or text alignment utilities to place spinners exactly where you need them in any situation.


##### Flex

```html
<
div
 
class
=
"d-flex justify-content-center"
>

  
<
div
 
class
=
"spinner-border"
 
role
=
"status"
>

    
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

  
</
div
>

</
div
>
```

```html
<
div
 
class
=
"d-flex align-items-center"
>

  
<
strong
>
Loading...
</
strong
>

  
<
div
 
class
=
"spinner-border ms-auto"
 
role
=
"status"
 
aria-hidden
=
"true"
></
div
>

</
div
>
```


##### Floats

Loading...

```html
<
div
 
class
=
"clearfix"
>

  
<
div
 
class
=
"spinner-border float-end"
 
role
=
"status"
>

    
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

  
</
div
>

</
div
>
```


##### Text align

Loading...

```html
<
div
 
class
=
"text-center"
>

  
<
div
 
class
=
"spinner-border"
 
role
=
"status"
>

    
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

  
</
div
>

</
div
>
```


### Size

Add `.spinner-border-sm` and `.spinner-grow-sm` to make a smaller spinner that can quickly be used within other components.

Loading...

Loading...

```html
<
div
 
class
=
"spinner-border spinner-border-sm"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow spinner-grow-sm"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>
```

Or, use custom CSS or inline styles to change the dimensions as needed.

Loading...

Loading...

```html
<
div
 
class
=
"spinner-border"
 
style
=
"width: 3rem; height: 3rem;"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>

<
div
 
class
=
"spinner-grow"
 
style
=
"width: 3rem; height: 3rem;"
 
role
=
"status"
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
div
>
```


### Buttons

Use spinners within buttons to indicate an action is currently processing or taking place. You may also swap the text out of the spinner element and utilize button text as needed.

```html
<
button
 
class
=
"btn btn-primary"
 
type
=
"button"
 
disabled
>

  
<
span
 
class
=
"spinner-border spinner-border-sm"
 
role
=
"status"
 
aria-hidden
=
"true"
></
span
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
button
>

<
button
 
class
=
"btn btn-primary"
 
type
=
"button"
 
disabled
>

  
<
span
 
class
=
"spinner-border spinner-border-sm"
 
role
=
"status"
 
aria-hidden
=
"true"
></
span
>

  Loading...

</
button
>
```

```html
<
button
 
class
=
"btn btn-primary"
 
type
=
"button"
 
disabled
>

  
<
span
 
class
=
"spinner-grow spinner-grow-sm"
 
role
=
"status"
 
aria-hidden
=
"true"
></
span
>

  
<
span
 
class
=
"visually-hidden"
>
Loading...
</
span
>

</
button
>

<
button
 
class
=
"btn btn-primary"
 
type
=
"button"
 
disabled
>

  
<
span
 
class
=
"spinner-grow spinner-grow-sm"
 
role
=
"status"
 
aria-hidden
=
"true"
></
span
>

  Loading...

</
button
>
```


### CSS


#### Variables

Added in v5.2.0

As part of Bootstrap’s evolving CSS variables approach, spinners now use local CSS variables on `.spinner-border` and `.spinner-grow` for enhanced real-time customization. Values for the CSS variables are set via Sass, so Sass customization is still supported, too.

Border spinner variables:

```scss
--#{$prefix}spinner-width
:
 
#{
$spinner-width
}
;

--#{$prefix}spinner-height
:
 
#{
$spinner-height
}
;

--#{$prefix}spinner-vertical-align
:
 
#{
$spinner-vertical-align
}
;

--#{$prefix}spinner-border-width
:
 
#{
$spinner-border-width
}
;

--#{$prefix}spinner-animation-speed
:
 
#{
$spinner-animation-speed
}
;

--#{$prefix}spinner-animation-name
:
 
spinner-border
;
```

Growing spinner variables:

```scss
--#{$prefix}spinner-width
:
 
#{
$spinner-width
}
;

--#{$prefix}spinner-height
:
 
#{
$spinner-height
}
;

--#{$prefix}spinner-vertical-align
:
 
#{
$spinner-vertical-align
}
;

--#{$prefix}spinner-animation-speed
:
 
#{
$spinner-animation-speed
}
;

--#{$prefix}spinner-animation-name
:
 
spinner-grow
;
```

For both spinners, small spinner modifier classes are used to update the values of these CSS variables as needed. For example, the `.spinner-border-sm` class does the following:

```scss
--#{$prefix}spinner-width
:
 
#{
$spinner-width-sm
}
;

--#{$prefix}spinner-height
:
 
#{
$spinner-height-sm
}
;

--#{$prefix}spinner-border-width
:
 
#{
$spinner-border-width-sm
}
;
```


#### Sass variables

```scss
$spinner-width
:
           
2
rem
;

$spinner-height
:
          
$spinner-width
;

$spinner-vertical-align
:
  
-
.125
em
;

$spinner-border-width
:
    
.25
em
;

$spinner-animation-speed
:
 
.75
s
;

$spinner-width-sm
:
        
1
rem
;

$spinner-height-sm
:
       
$spinner-width-sm
;

$spinner-border-width-sm
:
 
.2
em
;
```


#### Keyframes

Used for creating the CSS animations for our spinners. Included in `scss/_spinners.scss`.

```scss
@keyframes
 
spinner-border
 
{

  
to
 
{
 
transform
:
 
rotate
(
360
deg
)
 
#{
"/* rtl:ignore */"
}
;
 
}

}
```

```scss
@keyframes
 
spinner-grow
 
{

  
0
%
 
{

    
transform
:
 
scale
(
0
);

  
}

  
50
%
 
{

    
opacity
:
 
1
;

    
transform
:
 
none
;

  
}

}
```
