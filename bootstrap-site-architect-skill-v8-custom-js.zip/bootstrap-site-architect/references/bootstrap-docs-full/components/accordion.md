# Accordion

Source: Bootstrap offline docs `/docs/5.3/components/accordion/` extracted from the user-provided documentation archive.

Lead: Build vertically collapsing accordions in combination with our Collapse JavaScript plugin.

### How it works

The accordion uses collapse internally to make it collapsible. To render an accordion that’s expanded, add the `.open` class on the `.accordion`.

> Note: The animation effect of this component is dependent on the

prefers-reduced-motion

media query. See the

reduced motion section of our accessibility documentation

.


### Example

Click the accordions below to expand/collapse the accordion content.

This is the first item's accordion body.

It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the

.accordion-body

, though the transition does limit overflow.

This is the second item's accordion body.

It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the

.accordion-body

, though the transition does limit overflow.

This is the third item's accordion body.

It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the

.accordion-body

, though the transition does limit overflow.

```html
<
div
 
class
=
"accordion"
 
id
=
"accordionExample"
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#collapseOne"
 
aria-expanded
=
"true"
 
aria-controls
=
"collapseOne"
>

        Accordion Item #1

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"collapseOne"
 
class
=
"accordion-collapse collapse show"
 
data-bs-parent
=
"#accordionExample"
>

      
<
div
 
class
=
"accordion-body"
>

        
<
strong
>
This is the first item's accordion body.
</
strong
>
 It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the 
<
code
>
.accordion-body
</
code
>
, though the transition does limit overflow.

      
</
div
>

    
</
div
>

  
</
div
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button collapsed"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#collapseTwo"
 
aria-expanded
=
"false"
 
aria-controls
=
"collapseTwo"
>

        Accordion Item #2

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"collapseTwo"
 
class
=
"accordion-collapse collapse"
 
data-bs-parent
=
"#accordionExample"
>

      
<
div
 
class
=
"accordion-body"
>

        
<
strong
>
This is the second item's accordion body.
</
strong
>
 It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the 
<
code
>
.accordion-body
</
code
>
, though the transition does limit overflow.

      
</
div
>

    
</
div
>

  
</
div
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button collapsed"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#collapseThree"
 
aria-expanded
=
"false"
 
aria-controls
=
"collapseThree"
>

        Accordion Item #3

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"collapseThree"
 
class
=
"accordion-collapse collapse"
 
data-bs-parent
=
"#accordionExample"
>

      
<
div
 
class
=
"accordion-body"
>

        
<
strong
>
This is the third item's accordion body.
</
strong
>
 It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the 
<
code
>
.accordion-body
</
code
>
, though the transition does limit overflow.

      
</
div
>

    
</
div
>

  
</
div
>

</
div
>
```


#### Flush

Add `.accordion-flush` to remove some borders and rounded corners to render accordions edge-to-edge with their parent container.

Placeholder content for this accordion, which is intended to demonstrate the

.accordion-flush

class. This is the first item's accordion body.

Placeholder content for this accordion, which is intended to demonstrate the

.accordion-flush

class. This is the second item's accordion body. Let's imagine this being filled with some actual content.

Placeholder content for this accordion, which is intended to demonstrate the

.accordion-flush

class. This is the third item's accordion body. Nothing more exciting happening here in terms of content, but just filling up the space to make it look, at least at first glance, a bit more representative of how this would look in a real-world application.

```html
<
div
 
class
=
"accordion accordion-flush"
 
id
=
"accordionFlushExample"
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button collapsed"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#flush-collapseOne"
 
aria-expanded
=
"false"
 
aria-controls
=
"flush-collapseOne"
>

        Accordion Item #1

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"flush-collapseOne"
 
class
=
"accordion-collapse collapse"
 
data-bs-parent
=
"#accordionFlushExample"
>

      
<
div
 
class
=
"accordion-body"
>
Placeholder content for this accordion, which is intended to demonstrate the 
<
code
>
.accordion-flush
</
code
>
 class. This is the first item's accordion body.
</
div
>

    
</
div
>

  
</
div
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button collapsed"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#flush-collapseTwo"
 
aria-expanded
=
"false"
 
aria-controls
=
"flush-collapseTwo"
>

        Accordion Item #2

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"flush-collapseTwo"
 
class
=
"accordion-collapse collapse"
 
data-bs-parent
=
"#accordionFlushExample"
>

      
<
div
 
class
=
"accordion-body"
>
Placeholder content for this accordion, which is intended to demonstrate the 
<
code
>
.accordion-flush
</
code
>
 class. This is the second item's accordion body. Let's imagine this being filled with some actual content.
</
div
>

    
</
div
>

  
</
div
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button collapsed"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#flush-collapseThree"
 
aria-expanded
=
"false"
 
aria-controls
=
"flush-collapseThree"
>

        Accordion Item #3

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"flush-collapseThree"
 
class
=
"accordion-collapse collapse"
 
data-bs-parent
=
"#accordionFlushExample"
>

      
<
div
 
class
=
"accordion-body"
>
Placeholder content for this accordion, which is intended to demonstrate the 
<
code
>
.accordion-flush
</
code
>
 class. This is the third item's accordion body. Nothing more exciting happening here in terms of content, but just filling up the space to make it look, at least at first glance, a bit more representative of how this would look in a real-world application.
</
div
>

    
</
div
>

  
</
div
>

</
div
>
```


#### Always open

Omit the `data-bs-parent` attribute on each `.accordion-collapse` to make accordion items stay open when another item is opened.

This is the first item's accordion body.

It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the

.accordion-body

, though the transition does limit overflow.

This is the second item's accordion body.

It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the

.accordion-body

, though the transition does limit overflow.

This is the third item's accordion body.

It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the

.accordion-body

, though the transition does limit overflow.

```html
<
div
 
class
=
"accordion"
 
id
=
"accordionPanelsStayOpenExample"
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#panelsStayOpen-collapseOne"
 
aria-expanded
=
"true"
 
aria-controls
=
"panelsStayOpen-collapseOne"
>

        Accordion Item #1

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"panelsStayOpen-collapseOne"
 
class
=
"accordion-collapse collapse show"
>

      
<
div
 
class
=
"accordion-body"
>

        
<
strong
>
This is the first item's accordion body.
</
strong
>
 It is shown by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the 
<
code
>
.accordion-body
</
code
>
, though the transition does limit overflow.

      
</
div
>

    
</
div
>

  
</
div
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button collapsed"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#panelsStayOpen-collapseTwo"
 
aria-expanded
=
"false"
 
aria-controls
=
"panelsStayOpen-collapseTwo"
>

        Accordion Item #2

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"panelsStayOpen-collapseTwo"
 
class
=
"accordion-collapse collapse"
>

      
<
div
 
class
=
"accordion-body"
>

        
<
strong
>
This is the second item's accordion body.
</
strong
>
 It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the 
<
code
>
.accordion-body
</
code
>
, though the transition does limit overflow.

      
</
div
>

    
</
div
>

  
</
div
>

  
<
div
 
class
=
"accordion-item"
>

    
<
h2
 
class
=
"accordion-header"
>

      
<
button
 
class
=
"accordion-button collapsed"
 
type
=
"button"
 
data-bs-toggle
=
"collapse"
 
data-bs-target
=
"#panelsStayOpen-collapseThree"
 
aria-expanded
=
"false"
 
aria-controls
=
"panelsStayOpen-collapseThree"
>

        Accordion Item #3

      
</
button
>

    
</
h2
>

    
<
div
 
id
=
"panelsStayOpen-collapseThree"
 
class
=
"accordion-collapse collapse"
>

      
<
div
 
class
=
"accordion-body"
>

        
<
strong
>
This is the third item's accordion body.
</
strong
>
 It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the 
<
code
>
.accordion-body
</
code
>
, though the transition does limit overflow.

      
</
div
>

    
</
div
>

  
</
div
>

</
div
>
```


### Accessibility

Please read the collapse accessibility section for more information.


### CSS


#### Variables

Added in v5.2.0

As part of Bootstrap’s evolving CSS variables approach, accordions now use local CSS variables on `.accordion` for enhanced real-time customization. Values for the CSS variables are set via Sass, so Sass customization is still supported, too.

```scss
--#{$prefix}accordion-color
:
 
#{
$accordion-color
}
;

--#{$prefix}accordion-bg
:
 
#{
$accordion-bg
}
;

--#{$prefix}accordion-transition
:
 
#{
$accordion-transition
}
;

--#{$prefix}accordion-border-color
:
 
#{
$accordion-border-color
}
;

--#{$prefix}accordion-border-width
:
 
#{
$accordion-border-width
}
;

--#{$prefix}accordion-border-radius
:
 
#{
$accordion-border-radius
}
;

--#{$prefix}accordion-inner-border-radius
:
 
#{
$accordion-inner-border-radius
}
;

--#{$prefix}accordion-btn-padding-x
:
 
#{
$accordion-button-padding-x
}
;

--#{$prefix}accordion-btn-padding-y
:
 
#{
$accordion-button-padding-y
}
;

--#{$prefix}accordion-btn-color
:
 
#{
$accordion-button-color
}
;

--#{$prefix}accordion-btn-bg
:
 
#{
$accordion-button-bg
}
;

--#{$prefix}accordion-btn-icon
:
 
#{
escape-svg
(
$accordion-button-icon
)
}
;

--#{$prefix}accordion-btn-icon-width
:
 
#{
$accordion-icon-width
}
;

--#{$prefix}accordion-btn-icon-transform
:
 
#{
$accordion-icon-transform
}
;

--#{$prefix}accordion-btn-icon-transition
:
 
#{
$accordion-icon-transition
}
;

--#{$prefix}accordion-btn-active-icon
:
 
#{
escape-svg
(
$accordion-button-active-icon
)
}
;

--#{$prefix}accordion-btn-focus-border-color
:
 
#{
$accordion-button-focus-border-color
}
;

--#{$prefix}accordion-btn-focus-box-shadow
:
 
#{
$accordion-button-focus-box-shadow
}
;

--#{$prefix}accordion-body-padding-x
:
 
#{
$accordion-body-padding-x
}
;

--#{$prefix}accordion-body-padding-y
:
 
#{
$accordion-body-padding-y
}
;

--#{$prefix}accordion-active-color
:
 
#{
$accordion-button-active-color
}
;

--#{$prefix}accordion-active-bg
:
 
#{
$accordion-button-active-bg
}
;
```


#### Sass variables

```scss
$accordion-padding-y
:
                     
1
rem
;

$accordion-padding-x
:
                     
1
.25
rem
;

$accordion-color
:
                         
var
(
--
#{
$prefix
}
body-color
);

$accordion-bg
:
                            
var
(
--
#{
$prefix
}
body-bg
);

$accordion-border-width
:
                  
var
(
--
#{
$prefix
}
border-width
);

$accordion-border-color
:
                  
var
(
--
#{
$prefix
}
border-color
);

$accordion-border-radius
:
                 
var
(
--
#{
$prefix
}
border-radius
);

$accordion-inner-border-radius
:
           
subtract
(
$accordion-border-radius
,
 
$accordion-border-width
);

$accordion-body-padding-y
:
                
$accordion-padding-y
;

$accordion-body-padding-x
:
                
$accordion-padding-x
;

$accordion-button-padding-y
:
              
$accordion-padding-y
;

$accordion-button-padding-x
:
              
$accordion-padding-x
;

$accordion-button-color
:
                  
var
(
--
#{
$prefix
}
body-color
);

$accordion-button-bg
:
                     
var
(
--
#{
$prefix
}
accordion-bg
);

$accordion-transition
:
                    
$btn-transition
,
 
border-radius
 
.15
s
 
ease
;

$accordion-button-active-bg
:
              
var
(
--
#{
$prefix
}
primary-bg-subtle
);

$accordion-button-active-color
:
           
var
(
--
#{
$prefix
}
primary-text-emphasis
);

$accordion-button-focus-border-color
:
     
$input-focus-border-color
;

$accordion-button-focus-box-shadow
:
       
$btn-focus-box-shadow
;

$accordion-icon-width
:
                    
1
.25
rem
;

$accordion-icon-color
:
                    
$body-color
;

$accordion-icon-active-color
:
             
$primary-text-emphasis
;

$accordion-icon-transition
:
               
transform
 
.2
s
 
ease-in-out
;

$accordion-icon-transform
:
                
rotate
(
-
180
deg
);

$accordion-button-icon
:
         
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='
#{
$accordion-icon-color
}
'><path fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/></svg>")
;

$accordion-button-active-icon
:
  
url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='
#{
$accordion-icon-active-color
}
'><path fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/></svg>")
;
```
