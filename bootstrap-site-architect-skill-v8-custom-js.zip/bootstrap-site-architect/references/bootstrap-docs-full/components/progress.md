# Progress

Source: Bootstrap offline docs `/docs/5.3/components/progress/` extracted from the user-provided documentation archive.

Lead: Documentation and examples for using Bootstrap custom progress bars featuring support for stacked bars, animated backgrounds, and text labels.

> Note: New markup in v5.3.0 —

We’ve deprecated the previous HTML structure for progress bars and replaced it with a more accessible one. The previous structure will continue to work until v6.

See what’s changed in our migration guide.


### How it works

Progress components are built with two HTML elements, some CSS to set the width, and a few attributes. We don’t use [the HTML5 `<progress>` element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/progress), ensuring you can stack progress bars, animate them, and place text labels over them.

- We use the `.progress` as a wrapper to indicate the max
                value of the progress bar.
- The `.progress` wrapper also requires a
                `role="progressbar"` and
                `aria` attributes to make it accessible, including an
                accessible name (using `aria-label`,
                `aria-labelledby`, or similar).
- We use the inner `.progress-bar` purely for the visual
                bar and label.
- The `.progress-bar` requires an inline style, utility
                class, or custom CSS to set its width.
- We provide a special `.progress-stacked` class to
                create multiple/stacked progress bars.

Put that all together, and you have the following examples.

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Basic example"
 
aria-valuenow
=
"0"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 0%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Basic example"
 
aria-valuenow
=
"25"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 25%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Basic example"
 
aria-valuenow
=
"50"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 50%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Basic example"
 
aria-valuenow
=
"75"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 75%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Basic example"
 
aria-valuenow
=
"100"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 100%"
></
div
>

</
div
>
```


### Bar sizing


#### Width

Bootstrap provides a handful of utilities for setting width. Depending on your needs, these may help with quickly configuring the width of the `.progress-bar`.

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Basic example"
 
aria-valuenow
=
"75"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar w-75"
></
div
>

</
div
>
```


#### Height

You only set a `height` value on the `.progress` container, so if you change that value, the inner `.progress-bar` will automatically resize accordingly.

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Example 1px high"
 
aria-valuenow
=
"25"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
 
style
=
"height: 1px"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 25%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Example 20px high"
 
aria-valuenow
=
"25"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
 
style
=
"height: 20px"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 25%"
></
div
>

</
div
>
```


### Labels

Add labels to your progress bars by placing text within the `.progress-bar`.

25%

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Example with label"
 
aria-valuenow
=
"25"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar"
 
style
=
"width: 25%"
>
25%
</
div
>

</
div
>
```

Note that by default, the content inside the `.progress-bar` is controlled with `overflow: hidden`, so it doesn’t bleed out of the bar. If your progress bar is shorter than its label, the content will be capped and may become unreadable. To change this behavior, you can use `.overflow-visible` from the overflow utilities, but make sure to also define an explicit text color so the text remains readable. Be aware though that currently this approach does not take into account color modes.

Long label text for the progress bar, set to a dark color

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Example with label"
 
aria-valuenow
=
"10"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar overflow-visible text-dark"
 
style
=
"width: 10%"
>
Long label text for the progress bar, set to a dark color
</
div
>

</
div
>
```


### Backgrounds

Use background utility classes to change the appearance of individual progress bars.

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Success example"
 
aria-valuenow
=
"25"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-success"
 
style
=
"width: 25%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Info example"
 
aria-valuenow
=
"50"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-info"
 
style
=
"width: 50%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Warning example"
 
aria-valuenow
=
"75"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-warning"
 
style
=
"width: 75%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Danger example"
 
aria-valuenow
=
"100"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-danger"
 
style
=
"width: 100%"
></
div
>

</
div
>
```

> Note: Accessibility tip:

Using color to add meaning only provides a visual indication, which will not be conveyed to users of assistive technologies like screen readers. Please ensure the meaning is obvious from the content itself (e.g., the visible text) or is included through alternative means, such as additional text hidden with the

.visually-hidden

class.

If you’re adding labels to progress bars with a custom background color, make sure to also set an appropriate text color, so the labels remain readable and have sufficient contrast.

25%

50%

75%

100%

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Success example"
 
aria-valuenow
=
"25"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-success"
 
style
=
"width: 25%"
>
25%
</
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Info example"
 
aria-valuenow
=
"50"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-info text-dark"
 
style
=
"width: 50%"
>
50%
</
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Warning example"
 
aria-valuenow
=
"75"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-warning text-dark"
 
style
=
"width: 75%"
>
75%
</
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Danger example"
 
aria-valuenow
=
"100"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar bg-danger"
 
style
=
"width: 100%"
>
100%
</
div
>

</
div
>
```

Alternatively, you can use the new combined color and background helper classes.

75%

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Warning example"
 
aria-valuenow
=
"75"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar text-bg-warning"
 
style
=
"width: 75%"
>
75%
</
div
>

</
div
>
```


### Multiple bars

You can include multiple progress components inside a container with `.progress-stacked` to create a single stacked progress bar. Note that in this case, the styling to set the visual width of the progress bar *must* be applied to the `.progress` elements, rather than the `.progress-bar`s.

```html
<
div
 
class
=
"progress-stacked"
>

  
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Segment one"
 
aria-valuenow
=
"15"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
 
style
=
"width: 15%"
>

    
<
div
 
class
=
"progress-bar"
></
div
>

  
</
div
>

  
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Segment two"
 
aria-valuenow
=
"30"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
 
style
=
"width: 30%"
>

    
<
div
 
class
=
"progress-bar bg-success"
></
div
>

  
</
div
>

  
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Segment three"
 
aria-valuenow
=
"20"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
 
style
=
"width: 20%"
>

    
<
div
 
class
=
"progress-bar bg-info"
></
div
>

  
</
div
>

</
div
>
```


### Striped

Add `.progress-bar-striped` to any `.progress-bar` to apply a stripe via CSS gradient over the progress bar’s background color.

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Default striped example"
 
aria-valuenow
=
"10"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar progress-bar-striped"
 
style
=
"width: 10%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Success striped example"
 
aria-valuenow
=
"25"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar progress-bar-striped bg-success"
 
style
=
"width: 25%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Info striped example"
 
aria-valuenow
=
"50"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar progress-bar-striped bg-info"
 
style
=
"width: 50%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Warning striped example"
 
aria-valuenow
=
"75"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar progress-bar-striped bg-warning"
 
style
=
"width: 75%"
></
div
>

</
div
>

<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Danger striped example"
 
aria-valuenow
=
"100"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar progress-bar-striped bg-danger"
 
style
=
"width: 100%"
></
div
>

</
div
>
```


### Animated stripes

The striped gradient can also be animated. Add `.progress-bar-animated` to `.progress-bar` to animate the stripes right to left via CSS3 animations.

```html
<
div
 
class
=
"progress"
 
role
=
"progressbar"
 
aria-label
=
"Animated striped example"
 
aria-valuenow
=
"75"
 
aria-valuemin
=
"0"
 
aria-valuemax
=
"100"
>

  
<
div
 
class
=
"progress-bar progress-bar-striped progress-bar-animated"
 
style
=
"width: 75%"
></
div
>

</
div
>
```


### CSS


#### Variables

Added in v5.2.0

As part of Bootstrap’s evolving CSS variables approach, progress bars now use local CSS variables on `.progress` for enhanced real-time customization. Values for the CSS variables are set via Sass, so Sass customization is still supported, too.

```scss
--#{$prefix}progress-height
:
 
#{
$progress-height
}
;

@include
 rfs
(
$progress-font-size
,
 
--
#{
$prefix
}
progress
-
font-size
);

--#{$prefix}progress-bg
:
 
#{
$progress-bg
}
;

--#{$prefix}progress-border-radius
:
 
#{
$progress-border-radius
}
;

--#{$prefix}progress-box-shadow
:
 
#{
$progress-box-shadow
}
;

--#{$prefix}progress-bar-color
:
 
#{
$progress-bar-color
}
;

--#{$prefix}progress-bar-bg
:
 
#{
$progress-bar-bg
}
;

--#{$prefix}progress-bar-transition
:
 
#{
$progress-bar-transition
}
;
```


#### Sass variables

```scss
$progress-height
:
                   
1
rem
;

$progress-font-size
:
                
$font-size-base
 
*
 
.75
;

$progress-bg
:
                       
var
(
--
#{
$prefix
}
secondary-bg
);

$progress-border-radius
:
            
var
(
--
#{
$prefix
}
border-radius
);

$progress-box-shadow
:
               
var
(
--
#{
$prefix
}
box-shadow-inset
);

$progress-bar-color
:
                
$white
;

$progress-bar-bg
:
                   
$primary
;

$progress-bar-animation-timing
:
     
1
s
 
linear
 
infinite
;

$progress-bar-transition
:
           
width
 
.6
s
 
ease
;
```


#### Keyframes

Used for creating the CSS animations for `.progress-bar-animated`. Included in `scss/_progress-bar.scss`.

```scss
@if
 
$enable-transitions
 
{

  
@keyframes
 
progress-bar-stripes
 
{

    
0
%
 
{
 
background-position-x
:
 
$progress-height
;
 
}

  
}

}
```
