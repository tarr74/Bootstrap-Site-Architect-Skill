# Bootstrap custom JavaScript policy

Use this reference whenever a task needs behavior that Bootstrap does not already provide: custom filters, bespoke toggles, scroll effects, dynamic content, form helpers, small animations, AJAX/fetch, local UI state, or page-specific interactions.

## Immutable Bootstrap JavaScript

Never edit Bootstrap original JavaScript or vendor files. This includes:

- CDN Bootstrap URLs;
- `bootstrap.js`, `bootstrap.min.js`, `bootstrap.bundle.js`, `bootstrap.bundle.min.js`;
- anything under `node_modules/bootstrap/`;
- local vendor copies such as `assets/vendor/bootstrap/`, `vendor/bootstrap/`, `js/bootstrap*.js`, `assets/js/bootstrap*.js`, `public/vendor/bootstrap/`.

If a Bootstrap component needs different behavior, first use official options, data attributes, CSS, or Bootstrap's documented JavaScript API. If the required behavior is genuinely custom, create a separate site script that composes with Bootstrap instead of patching Bootstrap.

## Where custom JavaScript goes

Prefer existing project scripts first:

- `assets/js/site.js`
- `assets/js/main.js`
- `assets/js/custom.js`
- `assets/js/home.js`
- `js/site.js`
- `js/main.js`
- `js/custom.js`
- `public/js/app.js`
- a page-specific script already loaded by the template

If no custom script exists, create one. For a homepage, prefer `home.js`; for a site-wide behavior layer, prefer `site.js` or `custom.js`; for a one-off page, use a page-specific filename.

## No inline scripts by default

Do not put production behavior inside inline `<script>` blocks unless:

- the user explicitly asks for a paste-only snippet;
- the code is a tiny initialization that must be generated server-side;
- the existing project convention already uses inline initialization and changing it would be riskier.

For maintainable pages, create external script files and load them with `defer` or `type="module"`.

## Load order

When custom scripts depend on Bootstrap plugins, load Bootstrap first, then the custom script. Use `defer` for both when possible.

Good:

```html
<script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js" defer></script>
<script src="/assets/js/site.js" defer></script>
```

If the script is a module and does not depend on global Bootstrap APIs:

```html
<script type="module" src="/assets/js/home.js"></script>
```

Avoid loading jQuery for Bootstrap 5. Do not introduce a framework unless the project already uses one or the user explicitly requests it.

## Use Bootstrap before custom JS

Use Bootstrap's built-in features first:

- collapse, dropdown, modal, offcanvas, tabs, tooltip, popover, carousel, toast, scrollspy;
- `data-bs-*` attributes for simple behavior;
- documented Bootstrap JavaScript APIs only when lifecycle control is needed.

Do not write custom dropdowns, modals, accordions, nav toggles, or carousels if Bootstrap already solves the requirement cleanly.

## Vanilla JS conventions

- Scope behavior with `data-*` hooks or component classes.
- Use `DOMContentLoaded` only when needed; `defer` often makes it unnecessary.
- Use event delegation for repeated/dynamic elements.
- Keep selectors stable and semantic, e.g. `[data-filter-button]`, `[data-course-card]`.
- Avoid global variables; wrap small scripts in an IIFE or use modules.
- Make enhancements progressive: the page should still expose core content without JavaScript.
- Respect `prefers-reduced-motion` for animation or scroll behavior.
- Keep conversion-critical text visible before JS runs.
- Preserve existing IDs/classes used by PHP, CSS, analytics, or other scripts.

Example:

```js
(() => {
  const filters = document.querySelector('[data-course-filters]');
  if (!filters) return;

  filters.addEventListener('click', (event) => {
    const button = event.target.closest('[data-filter-button]');
    if (!button) return;

    const target = button.dataset.filterButton;
    document.querySelectorAll('[data-course-card]').forEach((card) => {
      card.hidden = target !== 'all' && card.dataset.category !== target;
    });
  });
})();
```

## Accessibility and performance

- Do not use JavaScript to fake native links/buttons; use real elements.
- Update `aria-expanded`, `aria-controls`, focus, and keyboard behavior when creating custom interactive components.
- Prefer CSS for visual hover/focus states and simple transitions.
- Avoid heavy animation libraries for small effects.
- Avoid blocking scripts in `<head>` unless technically required.
- Do not duplicate Bootstrap bundle or load both bundle and separate plugin files unless the project already has a deliberate build.

## Final reporting

When custom JavaScript is created or changed, report:

- script path;
- why custom JS was needed instead of Bootstrap's built-in behavior;
- whether it is loaded with `defer` or `type="module"`;
- whether it depends on Bootstrap APIs;
- confirmation that Bootstrap/vendor JS files were untouched.
