# Lightweight Bootstrap component patterns

Use these as starting points, not rigid templates.

## Course / service card

```html
<article class="card h-100 shadow-sm">
  <img src="..." class="card-img-top" alt="..." width="640" height="360" loading="lazy">
  <div class="card-body d-flex flex-column">
    <h2 class="h5 card-title">Titolo</h2>
    <p class="card-text">Descrizione breve.</p>
    <a href="..." class="btn btn-primary mt-auto">Scopri di più</a>
  </div>
</article>
```

## FAQ accordion

Use unique IDs and real questions already present in the page/user content.

```html
<div class="accordion" id="faqAccordion">
  <div class="accordion-item">
    <h2 class="accordion-header" id="faqOneHeading">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faqOne" aria-expanded="true" aria-controls="faqOne">
        Domanda reale
      </button>
    </h2>
    <div id="faqOne" class="accordion-collapse collapse show" aria-labelledby="faqOneHeading" data-bs-parent="#faqAccordion">
      <div class="accordion-body">Risposta reale.</div>
    </div>
  </div>
</div>
```

## Lead form row

Preserve existing `action`, `method`, and `name` values when refactoring.

```html
<form class="row g-3" method="post" action="...">
  <div class="col-12 col-md-6">
    <label for="name" class="form-label">Nome</label>
    <input type="text" class="form-control" id="name" name="Name" autocomplete="name" required>
  </div>
  <div class="col-12 col-md-6">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" id="email" name="Email" autocomplete="email" required>
  </div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Invia</button>
  </div>
</form>
```

## Full-bleed background with contained content

```html
<section class="site-band py-5">
  <div class="container">
    <div class="row g-4 align-items-center">
      <div class="col-12 col-lg-6">...</div>
      <div class="col-12 col-lg-6">...</div>
    </div>
  </div>
</section>
```
