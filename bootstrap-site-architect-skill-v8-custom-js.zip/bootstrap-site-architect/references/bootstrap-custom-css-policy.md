# Bootstrap custom CSS policy

Use this reference whenever a task touches colors, typography, page-specific styles, visual identity, or non-standard Bootstrap presentation.

## Immutable Bootstrap files

Never edit Bootstrap's original files. This includes:

- CDN Bootstrap URLs;
- `bootstrap.css`, `bootstrap.min.css`, `bootstrap.rtl.css`, `bootstrap.rtl.min.css`;
- `bootstrap.js`, `bootstrap.bundle.js`, minified variants;
- anything under `node_modules/bootstrap/`;
- local vendor copies such as `assets/vendor/bootstrap/`, `vendor/bootstrap/`, `css/bootstrap*.css`, `js/bootstrap*.js`.

If the user asks to change Bootstrap itself, explain that project-specific styling belongs in a separate stylesheet loaded after Bootstrap. Only Sass theming is acceptable when the project already has a Bootstrap Sass build pipeline and the user explicitly requests a theme build.

## Where custom CSS goes

Prefer existing custom files first:

- `assets/css/custom.css`
- `assets/css/site.css`
- `assets/css/home.css`
- `css/style.css`
- `css/custom.css`
- `public/css/app.css`
- project-specific files already loaded after Bootstrap

If no custom stylesheet exists, create one and link it after Bootstrap. For a homepage, prefer `home.css`; for a general site layer, prefer `custom.css` or `site.css`; for a one-off page, use a page-specific filename.

## No inline styles by default

Do not use `style="..."` for production HTML/PHP unless:

- the user explicitly asks for an inline snippet;
- the value is generated dynamically and cannot be expressed safely otherwise;
- a single throwaway example is requested.

For maintainable pages, create classes and CSS rules.

## Selector discipline

Prefer scoped selectors:

```css
.home-split-section { ... }
.home-split-section a { ... }
.home-split-section__title { ... }
```

Avoid fragile global overrides:

```css
h1 { color: red; }
.container { max-width: 1600px; }
.card { border-radius: 0; }
.btn-primary { background: #000; }
```

Global Bootstrap variable overrides are acceptable only in an intentional site theme file and only when they improve consistency across the full site.

## Class naming

Use readable semantic naming:

- `home-hero`
- `course-landing-hero`
- `pge-contact-panel`
- `archive-card-grid`
- `teacher-profile-sidebar`

Avoid:

- `left-column`
- `right-column`
- `red-title`
- `box2`
- `new-section-final`

## CSS variable policy

Use variables for repeated values or coherent visual systems:

```css
.course-landing {
  --course-bg: #0f1117;
  --course-fg: #f5f1e8;
  --course-accent: #ff6b4a;
  --course-muted: #b8bdcc;
}
```

Then use the variables inside the scope.

## Link order check

Before finalizing, verify the custom file is loaded after Bootstrap and before page-specific scripts that depend on computed styles.

Good:

```html
<link rel="stylesheet" href="/assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/css/custom.css">
```

Bad:

```html
<link rel="stylesheet" href="/assets/css/custom.css">
<link rel="stylesheet" href="/assets/vendor/bootstrap/css/bootstrap.min.css">
```

## Final reporting

When custom CSS is created or changed, report:

- stylesheet path;
- why custom CSS was needed instead of Bootstrap utilities;
- whether Bootstrap original files were untouched;
- where the stylesheet is linked.


## Related JavaScript rule

For custom behavior, do not edit Bootstrap JavaScript. Put site-specific scripts in external files such as `site.js`, `custom.js`, or `home.js` and load them separately. See `references/bootstrap-custom-js-policy.md`.
