# Third-party frontend-design source note

This Bootstrap skill incorporates an adapted design-quality layer inspired by the community `frontend-design` Codex skill in `vipulgupta2048/codex-skills`, specifically the `skills/frontend-design` directory.

The source project describes the skill as a way to create distinctive, production-grade frontend interfaces with high design quality, using a `SKILL.md`, references such as an aesthetic playbook and implementation patterns, and a vanilla starter asset. The repository indicates an MIT license.

This package does not require the external skill at runtime. It adapts the principles into a Bootstrap-first workflow:

- Bootstrap remains the HTML/CSS/JS framework;
- project-specific aesthetics go into custom CSS loaded after Bootstrap;
- PHP/HTML templates remain safe to refactor;
- SEO, accessibility, performance, responsive behavior, and form integrity remain mandatory.

Manual installation of the original community skill, if the user wants it separately, follows the repository structure:

```bash
mkdir -p ~/.agents/skills
git clone https://github.com/vipulgupta2048/codex-skills.git
cp -r codex-skills/skills/frontend-design ~/.agents/skills/
```

Some examples online omit the intermediate `skills/` path. Check the cloned repository before copying.
