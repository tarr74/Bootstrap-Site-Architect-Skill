# Safe refactor for existing HTML/PHP Bootstrap pages

## Audit first

Before patching, inspect:

- file tree and entry page,
- `AGENTS.md`, README, build scripts,
- PHP includes for header/footer/nav,
- CSS/JS imports and Bootstrap version,
- form handlers and hidden fields,
- SEO head tags and schema,
- custom CSS naming conventions,
- existing JavaScript dependencies.

## Preserve by default

- `action`, `method`, `name`, `id` when used by JS/backend,
- hidden fields, honeypots, CSRF tokens,
- PHP variables and echo logic,
- include/require paths,
- analytics, pixels, canonical, schema, robots,
- legal/privacy text,
- relative URLs and asset paths,
- comments that explain business logic.

## Patch strategy

- Modify the smallest coherent block.
- Do not reformat the entire file unless asked.
- Prefer adding scoped classes instead of brittle inline styles.
- Use external custom CSS after Bootstrap.
- Avoid introducing a build system into a simple PHP site unless requested.
- For legacy Bootstrap 4, migrate intentionally: `data-bs-*`, updated utilities, dropped jQuery assumptions.

## Form-specific rules

- Do not rename fields casually.
- Add labels if missing.
- Keep or add `autocomplete`.
- Keep existing validation messages unless improving them.
- Client validation is progressive enhancement; server validation is final.
- Public forms should use honeypot and CSRF when project supports it.

## PHP output

When adding dynamic output:

```php
<?= htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8') ?>
```

For attributes:

```php
href="<?= htmlspecialchars($url ?? '#', ENT_QUOTES, 'UTF-8') ?>"
```

Do not over-escape static HTML. Do not double-escape already escaped project helpers.
