# Visual design loop / WYSIWYG-like workflow

This skill cannot become a true drag-and-drop editor by itself. It should behave like a visual web designer with code control.

## Design session mode

1. Inspect files and identify the page entry point.
2. Build a block map:
   - `[HEADER]`
   - `[NAVBAR]`
   - `[HERO]`
   - `[FEATURES]`
   - `[CARDS]`
   - `[FORM]`
   - `[FAQ]`
   - `[FOOTER]`
3. If useful, add safe stable attributes:
   - `id="hero-home"`
   - `data-edit-block="hero"`
4. Present a compact interface:
   - block to edit,
   - layout option,
   - colors,
   - text/content,
   - components,
   - breakpoint behavior.
5. Apply targeted patch.
6. Preview locally when tools are available.
7. Check desktop/tablet/mobile, console, keyboard, forms, and visible SEO.
8. Iterate from user feedback.

## Optional editor overlay

During local development only, Codex may inject `assets/editor/visual-overlay.css` and `assets/editor/visual-overlay.js` to outline Bootstrap containers/rows/columns and show editable block labels. Remove these from production unless the user explicitly wants to keep them.

## DOM map format

```text
[HEADER] header.site-header
  [NAVBAR] nav.navbar
[MAIN] main
  [HERO] section#hero-home[data-edit-block="hero"]
  [COURSE GRID] section#courses[data-edit-block="courses"]
  [CONTACT FORM] section#contact[data-edit-block="form"]
[FOOTER] footer.site-footer
```

## Preview checklist

- 1440 desktop: no awkward max-width, broken images, console errors.
- 1024 tablet: columns stack/flow correctly.
- 390 mobile: no horizontal scroll, CTA visible, forms usable.
- Keyboard: nav, buttons, accordions, modals, forms reachable.
- Console: no JS errors.
- Forms: handler fields preserved.

Do not claim a preview happened unless it actually happened.
