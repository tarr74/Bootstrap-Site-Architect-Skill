# Compact final checklists

## Before editing existing files

- [ ] Found the entry page and relevant includes.
- [ ] Detected Bootstrap version/import style.
- [ ] Located custom CSS/JS conventions.
- [ ] Confirmed Bootstrap/vendor CSS and JS files will not be modified.
- [ ] Preserved PHP/form/backend-sensitive attributes.
- [ ] Identified insertion/edit target.

## Natural-language section

- [ ] Parsed width/container.
- [ ] Parsed row/columns/fractions.
- [ ] Validated colors.
- [ ] Chose breakpoint behavior.
- [ ] Used Bootstrap utilities where appropriate.
- [ ] Added scoped external CSS for exact values.
- [ ] Avoided multiple production H1s unless requested.

## Text edit

- [ ] Target block identified.
- [ ] Exact text preserved or rewrite scope clear.
- [ ] No invented facts.
- [ ] Heading hierarchy preserved/improved.
- [ ] SEO metadata updated only when needed.

## Bootstrap QA

- [ ] `.container`/`.row`/`.col-*` structure valid.
- [ ] Bootstrap 5 `data-bs-*` used.
- [ ] Unique IDs for components.
- [ ] No jQuery added for Bootstrap behavior.
- [ ] Images/forms/components accessible.

## SEO/performance/a11y

- [ ] Title/H1/meta checked.
- [ ] Alt/labels/focus/contrast checked where relevant.
- [ ] No unnecessary JS dependencies.
- [ ] Custom JS, if needed, lives in an external project script loaded with `defer` or `type="module"`.
- [ ] Media dimensions/lazy loading considered.
- [ ] No claims of unrun tests.

## Final answer

- [ ] Files changed/generated.
- [ ] What changed and why.
- [ ] How to preview/test.
- [ ] What was not verified.
- [ ] One next step.
