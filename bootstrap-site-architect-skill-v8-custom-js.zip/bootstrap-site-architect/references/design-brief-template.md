# Design brief template

Use only when the task is broad or underspecified. For simple edits, do not ask all questions.

```text
Obiettivo pagina:
File/URL da modificare:
Pubblico e query SEO:
Contenuti/testi da inserire:
Sezioni richieste:
Componenti Bootstrap:
Colori/identità visiva:
Interazioni JS:
Form/backend da preservare:
Vincoli tecnici:
```

If the user gives enough information, fill missing fields with safe assumptions and proceed.
