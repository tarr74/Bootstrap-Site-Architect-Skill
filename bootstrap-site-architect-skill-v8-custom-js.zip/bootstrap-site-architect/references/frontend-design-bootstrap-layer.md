# Frontend-design layer for Bootstrap projects

Use this reference when a Bootstrap page must feel designed, not merely assembled from default components. It adapts the `frontend-design` skill approach to a Bootstrap-first HTML/PHP workflow.

## Non-negotiable Bootstrap boundary

Bootstrap is the structural framework. Do not edit Bootstrap source or distributed files:

- never modify `bootstrap.css`, `bootstrap.min.css`, `bootstrap.rtl.css`, `bootstrap.bundle.js`, `bootstrap.bundle.min.js`, `bootstrap.min.js`, files under `node_modules/bootstrap/`, or local vendor copies;
- put all site-specific behavior in external custom JS files such as `site.js`, `custom.js`, or `home.js`;
- do not paste custom rules into Bootstrap files;
- do not solve design by globally overriding `.container`, `.row`, `.col-*`, `.btn`, `.card`, `.navbar`, etc. unless the user explicitly asks for a theme layer and the override is scoped/documented;
- load one custom stylesheet after Bootstrap, for example `assets/css/custom.css`, `assets/css/home.css`, `css/site.css`, or the existing project stylesheet;
- place page-specific design in a page stylesheet such as `home.css`, `corso-filmmaker.css`, `landing.css`, or a scoped section file if that is the project convention.

Good include order:

```html
<link rel="stylesheet" href="/assets/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/assets/css/custom.css">
<link rel="stylesheet" href="/assets/css/home.css">
```

## Role split

Bootstrap should handle:

- responsive containers, grid, gutters, columns;
- accessible form structure and components;
- navbar/collapse/offcanvas/modal/dropdown/accordion behavior;
- helpers/utilities for spacing, display, flex, position, ratio, text, visibility;
- predictable mobile-first composition.

The custom CSS file should handle:

- brand or page color tokens;
- typography beyond Bootstrap defaults;
- exact background treatments;
- unusual hero compositions;
- reusable card skins;
- subject-specific decorative motifs;
- section-specific link colors, heading colors, borders, radii, shadows;
- restrained motion and `prefers-reduced-motion` fallbacks;
- anything the user specified that cannot be expressed cleanly with Bootstrap utilities.

## Design workflow

For a new page, landing, PHP template, or substantial redesign:

1. Collect or infer: purpose, audience, conversion goal, content type, technical stack, Bootstrap version, page constraints.
2. Choose one aesthetic direction, not five. The page should have a clear voice.
3. Choose one signature move: a typographic rule, cinematic hero crop, visible grid, accent stripe, editorial pull quote, tactile paper texture, neon rail, industrial coordinate labels, etc.
4. Define a compact token layer in the custom CSS file.
5. Build semantic HTML/PHP with Bootstrap classes for structure.
6. Add scoped custom classes for the visual identity.
7. Test responsive behavior, contrast, keyboard focus, console errors, and page weight where tools allow it.

Do not produce random decorative blobs, generic SaaS gradients, purple AI dashboards, floating glass cards, or unmotivated emoji/icon clutter unless the brief asks for that language.

## Aesthetic anchors adapted to Bootstrap

Pick one only, then adapt it to the actual subject.

### Brutalist raw

Best for: manifestos, experimental portfolios, provocative landing pages, art-school projects, event pages.

Bootstrap usage:

- `.container`, `.row`, `.col-*` for rigid grid skeleton;
- `.border`, `.border-2`, spacing utilities, table-like panels;
- custom CSS for oversized type, visible rules, hard contrast, angular labels.

Custom CSS traits:

- charcoal/ivory base;
- one acidic accent;
- thick borders;
- flat surfaces;
- numbered blocks;
- hover inversion.

### Editorial / magazine

Best for: cultural pages, cinema schools, course pages, essays, archives, artist/docent profiles.

Bootstrap usage:

- grid for columns, `.ratio` for media, `.figure`, `.lead`, cards only when semantically useful;
- custom CSS for typography, pull quotes, paper texture, hairline rules, image crops.

Custom CSS traits:

- deep ink, warm paper, restrained accent;
- generous line-height;
- asymmetrical whitespace;
- long-form readable content;
- small labels and typographic hierarchy.

### Retro-futuristic / neon

Best for: games, tech demos, audiovisual labs, music/AI projects, playful campaign pages.

Bootstrap usage:

- grid/card/offcanvas/modal only as structural primitives;
- custom CSS for scanlines, glows, console labels, neon borders, animated metadata strips.

Custom CSS traits:

- dark base;
- cyan/magenta/green accent restraint;
- thin outlines;
- subtle glow, not unreadable glow;
- reduced-motion fallback.

### Soft craft / pastel

Best for: workshops, photography, design, personal portfolio, welcoming institutional pages.

Bootstrap usage:

- spacing, cards, forms, responsive columns;
- custom CSS for warm palette, rounded visual system, soft textures, tactile shadows.

Custom CSS traits:

- warm pastel base;
- clay/sage/accent palette;
- rounded card skins;
- calm motion;
- high readability.

### Industrial / utilitarian

Best for: dashboards, technical services, institutional directories, operational pages, internal tools.

Bootstrap usage:

- tables, forms, pagination, list groups, grid, badges;
- custom CSS for labels, coordinates, boxed panels, diagonal hatches, status rails.

Custom CSS traits:

- cold neutral palette;
- hazard or teal accent;
- labeled modules;
- compact hierarchy;
- functional visual rhythm.

## Token system for Bootstrap custom CSS

Prefer scoped tokens instead of scattered hard-coded values.

```css
:root {
  --site-bg: #0b0c10;
  --site-surface: #151821;
  --site-text: #f7f2e9;
  --site-muted: #9aa1b5;
  --site-accent: #ff6b4a;
  --site-accent-2: #6b9bff;
  --site-border: rgba(255, 255, 255, .14);
  --site-radius: 1.125rem;
  --site-shadow: 0 1.125rem 2.75rem rgba(0, 0, 0, .28);
  --site-ease: cubic-bezier(.22, 1, .36, 1);
}
```

For a specific page, use a prefix:

```css
.home-hero { ... }
.course-card { ... }
.pge-contact-form { ... }
```

Avoid generic custom names like `.box1`, `.left`, `.right`, `.blue`, `.big-title` unless generating a throwaway snippet. Prefer semantic names that survive redesigns.

## Bootstrap + custom class pattern

Good Bootstrap-first markup:

```html
<section class="home-hero py-5 py-lg-6" data-edit-block="hero">
  <div class="container">
    <div class="row align-items-center g-4 g-lg-5">
      <div class="col-12 col-lg-7">
        <p class="home-eyebrow mb-2">Scuola di cinema</p>
        <h1 class="display-4 fw-bold mb-3">Un titolo forte, non un segnaposto generico</h1>
        <p class="lead mb-4">Testo concreto, leggibile, orientato all'azione.</p>
        <a class="btn btn-primary btn-lg home-cta" href="#contatti">Richiedi informazioni</a>
      </div>
      <div class="col-12 col-lg-5">
        <div class="home-hero-card p-4 p-lg-5">...</div>
      </div>
    </div>
  </div>
</section>
```

Corresponding custom CSS belongs in `home.css` or `custom.css`, not in Bootstrap:

```css
.home-hero {
  --hero-bg: #101010;
  --hero-fg: #f7f2e9;
  --hero-accent: #ff6b4a;
  background: var(--hero-bg);
  color: var(--hero-fg);
}

.home-eyebrow {
  color: var(--hero-accent);
  letter-spacing: .14em;
  text-transform: uppercase;
  font-size: .8125rem;
}

.home-hero-card {
  border: 1px solid rgba(255, 255, 255, .16);
  border-radius: 1.25rem;
  background: rgba(255, 255, 255, .04);
}
```

## Natural-language design requests

When the user describes layout and colors in ordinary language, translate into Bootstrap structure + external CSS.

Example:

> una section larga come tutto il sito, due colonne, la prima 4/12 grigia con testo arancione e link magenta, la seconda 8/12 nera con testo bianco e titoli verde oliva

Output approach:

- HTML uses `.container`, `.row`, `col-12 col-lg-4`, `col-12 col-lg-8`;
- custom CSS defines `.custom-split-section`, `.custom-split-section__intro`, `.custom-split-section__body`, link and heading colors;
- invalid colors trigger a clarification;
- if the block is integrated into a production page, avoid creating a second H1 unless it is truly the page H1.

## Motion rules

Use motion sparingly and only in custom CSS/JS:

- hover/focus polish may be CSS-only;
- page-load reveals need `prefers-reduced-motion`;
- Bootstrap JS components should keep Bootstrap behavior;
- do not add animation libraries unless the project already uses them or the user asks;
- never make conversion-critical text invisible before JS runs.

## Anti-Codex-look checklist

Before finalizing a design, ask internally:

- Could this design fit any random AI SaaS if the logo changed?
- Does it rely on generic purple gradients/glassmorphism/cards?
- Is the subject visible in structure, metaphor, copy, or typography?
- Is there one memorable decision, or just many decorations?
- Are Bootstrap defaults still too visible?
- Does the design remain readable, accessible, fast, and responsive?

Fix generic output by improving hierarchy and concept, not by adding noise.

## Credit-efficient use

Do not read this whole file for minor tasks like changing a margin or a text label. Load it when:

- the task is a new page/landing/template;
- the user asks for a more elegant/less AI-looking result;
- the page redesign needs art direction;
- visual style choices are central to the request.

For Bootstrap class uncertainty, route back to `bootstrap-doc-router.md` and the exact Bootstrap doc file.
