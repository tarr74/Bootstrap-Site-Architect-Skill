# Text and content editing inside web pages

Use this reference when the user wants to add, replace, shorten, rewrite, translate, or reorganize text in HTML/PHP pages.

## Modes

1. **Exact insertion**: user provides exact text. Insert it, preserving words, line breaks where meaningful, accents, and links.
2. **Editorial rewrite**: improve clarity, tone, hierarchy, conversion, or SEO without inventing facts.
3. **Structural content edit**: split text into headings, paragraphs, cards, FAQ, lists, or CTAs.
4. **SEO copy edit**: update `<title>`, meta description, H1/H2, intro, internal anchor text.
5. **Form copy edit**: labels, placeholders, help text, validation messages, privacy microcopy.

## Safety rules

- Never invent dates, prices, teachers, awards, reviews, addresses, legal promises, course outcomes, or factual claims.
- Preserve PHP variables, template tags, shortcodes, includes, translation calls, and dynamic echoes.
- Escape user-visible dynamic PHP output with `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')` when generating new code.
- Do not replace a dynamic value with static text.
- Keep links unless requested; preserve `href`, tracking parameters, `rel`, `target`, and classes.
- Keep `name` attributes in forms.
- Maintain one H1 per production page unless the current site intentionally differs.
- Do not overstuff keywords.
- Prefer concise paragraphs and scannable sections.

## Editing process

1. Locate target block by selector, heading, visible text, or page map.
2. Determine whether the task is exact text insertion or rewrite.
3. Patch only the relevant text/block.
4. If the new visible topic changes the page meaning, update SEO metadata.
5. If copy becomes longer/shorter, check layout responsiveness.
6. Report exactly what changed.

## User-facing design interface

For ambiguous text edits ask one focused question:

- “Dove vuoi inserirlo: hero, sezione centrale, form, footer o meta description?”
- “Vuoi mantenere tono istituzionale, promozionale, ironico o editoriale?”
- “Il testo deve sostituire quello esistente o aggiungersi sotto?”

Avoid asking if the user gives a precise block and text.
