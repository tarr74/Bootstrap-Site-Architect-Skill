// Temporary Bootstrap visual editing helper. Remove from production.
(() => {
  document.documentElement.dataset.bootstrapEditorOverlay = 'true';
  document.querySelectorAll('section, header, main, footer, nav, form').forEach((el, i) => {
    if (!el.dataset.editBlock) el.dataset.editBlock = el.id || el.className?.toString().split(/\s+/).filter(Boolean).slice(0,2).join('.') || `block-${i+1}`;
    if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
  });
  console.info('[bootstrap-site-architect] visual overlay active. Remove overlay CSS/JS before production.');
})();
