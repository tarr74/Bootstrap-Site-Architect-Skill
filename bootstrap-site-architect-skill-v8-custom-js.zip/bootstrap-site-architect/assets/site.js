// Site-specific JavaScript loaded separately from Bootstrap.
// Do not paste this code into Bootstrap vendor files.

(() => {
  // Add progressive enhancements here only when Bootstrap does not already provide the behavior.
})();
